<?php

namespace App\Http\Controllers;

use App\Models\Add_role;
use App\Models\Employee;
use App\Models\Invoice;
use App\Models\Roles;
use Exception;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin_auth');
    }
    public function invoice_create()
    {
        $invoice=Invoice::all();
        $count=count($invoice)+189001;
        $employees=Employee::all();
        return view('admin.invoice_create',compact('count','employees'));
    }
    public function get_employee_data(Request $request)
    {
        $eid=$request->input('eid');
        $employee=Employee::select('employee_id','employee_name')->where('id',$eid)->first();
        $role=Add_role::select('role_id','salary')->where('employee_id',$eid)->first();
        $role_name=Roles::select('role_name')->find($eid);
        $array=['employee_id'=>$employee->employee_id,'employee_name'=>$employee->employee_name,'role_id'=>$role->role_id,'salary'=>$role->salary,'role_name'=>$role_name->role_name];
        return $array;
    }
    public function store_invoice(Request $request)
    {
        $request->validate([
            'invoice_no'=>'required',
            'invoice_date'=>'required',
            'employee_name'=>'required',
            'employee_id'=>'required',
            'department'=>'required',
            'position'=>'required',
            'pay_period_from'=>'required',
            'pay_period_to'=>'required',
            'total_working_days'=>'required',
            'present_days'=>'required',
            'gross_pay'=>'required',
            'tax'=>'required',
            'health_insurance'=>'required',
            'retirement'=>'required',
            'total_deduction'=>'required',
            'net_pay'=>'required'
        ]);
        $invoice_no=$request->input('invoice_no');
        $invoice_date=$request->input('invoice_date');
        $employee_name=$request->input('employee_name');
        $employee_id=$request->input('employee_id');
        $department=$request->input('department');
        $position=$request->input('position');
        $pay_period_from=$request->input('pay_period_from');
        $pay_period_to=$request->input('pay_period_to');
        $total_working_days=$request->input('total_working_days');
        $present_days=$request->input('present_days');
        $gross_pay=$request->input('gross_pay');
        $tax=$request->input('tax');
        $health_insurance=$request->input('health_insurance');
        $retirement=$request->input('retirement');
        $total_deduction=$request->input('total_deduction');
        $net_pay=$request->input('net_pay');

        try
        {
            Invoice::create([
               'invoice_no'=>$invoice_no,
            'invoice_date'=>$invoice_date,
            'employee_name'=>$employee_name,
            'employee_id'=>$employee_id,
            'department'=>$department,
            'position'=>$position,
            'pay_period_from'=>$pay_period_from,
            'pay_period_to'=>$pay_period_to,
            'total_working_days'=>$total_working_days,
            'present_days'=>$present_days,
            'gross_pay'=>$gross_pay,
            'tax'=> $tax,
            'health_insurance'=>$health_insurance,
            'retirement'=>$retirement,
            'total_deduction'=>$total_deduction,
            'net_pay'=>$net_pay
            ]);
            return redirect()->route('user.invoice_create')->with('success','Invoice Added successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.invoice_create')->with('error','Error to Add Invoice');
        }
    }
    public function manage_invoice()
    {
        $invoices=Invoice::leftJoin('employees','invoices.employee_name','=','employees.id')->select('employees.employee_name as emp_name','invoices.*')->orderBy('id','desc')->get();
        return view('admin.manage_invoice',compact('invoices'));
    }
    public function view_invoice($id)
    {
        $invoice=Invoice::leftJoin('employees','invoices.employee_name','=','employees.id')->select('employees.employee_name as emp_name','invoices.*')->where('employees.id',$id)->orderBy('id','desc')->first();
        return view('admin.view_invoice',compact('invoice'));
    }
}
