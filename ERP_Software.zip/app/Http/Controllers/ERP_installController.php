<?php

namespace App\Http\Controllers;

use App\Models\PurchaseErp;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ERP_installController extends Controller
{
    public function index()
    {
        return view('erp_install.main');
    }
    public function purchase_check(Request $request)
    {
        $request->validate([
            'user_id'=>'required|regex:/^[a-zA-Z0-9$#@.]+$/',
            'purchase_key'=>'required|regex:/^[a-zA-Z0-9$#@]+$/'
        ]);

        $user_id=$request->input('user_id');
        $purchase_key=$request->input('purchase_key');

        $erp=PurchaseErp::where('purchase_user_id',$user_id)->where('purchase_key',$purchase_key)->first();
        if($erp)
        {
            session()->put('pid',$erp->purchase_id);
            return redirect()->route('erp_install.step2');
        }
        else
        {
            return redirect()->route('erp_install.step1')->with('error','User id or purchase id incorrect');
        }
    }
    public function step2()
    {
        if(session()->has('pid'))
        {
             $sql_version=DB::select('select version() as version');
             $sql_ver=$sql_version[0]->version;
             return view('erp_install.step2',compact('sql_ver'));
        }
        else
        {
            return redirect()->route('erp_install.step1')->with('error','Complete Step 1 to Continue');
        }
    }
    public function step3()
    {
        if(session()->has('pid'))
        {
             return view('erp_install.step3');
        }
        else
        {
            return redirect()->route('erp_install.step1')->with('error','Complete Step 1 to Continue');
        }
    }
    public function step3_backend(Request $request)
    {
        $request->validate([
            'dbname'=>'required|regex:/^[a-zA-Z0-9_]+$/',
            'username'=>'required|regex:/^[a-zA-Z0-9$#@._]+$/',
            'password'=>'required|regex:/^[a-zA-Z0-9$#@._]+$/',
            'hostname'=>'required|regex:/^[a-zA-Z0-9$#@._]+$/'
        ]);

        $dbname=$request->input('dbname');
        $username=$request->input('username');
        $password=$request->input('password');
        $hostname=$request->input('hostname');

        session([
            'dbname'=>$dbname,
            'username'=>$username,
            'password'=>$password,
            'hostname'=>$hostname
        ]);

        return redirect()->route('erp_install.step4');
    }
    public function step4()
    {
        if(session()->has('pid') && session()->has('dbname'))
        {
             return view('erp_install.step4');
        }
        else
        {
            return redirect()->route('erp_install.step3')->with('error','Complete Step 3 to Continue');
        }
    }
    public function step4_backend(Request $request)
    {
        $request->validate([
            'email'=>'required|email|regex:/^[a-zA-Z0-9$#@._]+$/',
            'password'=>'required|regex:/^[a-zA-Z0-9$#@._]+$/'
        ]);

        $login_email=$request->input('email');
        $login_password=$request->input('password');

        $user=new User();
        $user->email=$login_email;
        $user->password=password_hash($login_password,PASSWORD_DEFAULT);
        try
        {
            $user->save();
            return redirect()->route('erp_install.step5');
        }
        catch(Exception $e)
        {
            return redirect()->route('erp_install.step4')->with('error','Error to add Data in database');
        }

    }
    public function step5()
    {
        if(session()->has('pid') && session()->has('dbname'))
        {
             return view('erp_install.step5');
        }
        else
        {
            return redirect()->route('erp_install.step4')->with('error','Complete Step 3 to Continue');
        }
    }
}
