<?php

namespace App\Http\Controllers;
use Exception;
use App\Models\Employee;
use App\Models\Time_tracking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TimeTrackingController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin_auth');
    }
    public function time_tracking()
    {
        //$employees=Employee::all();
        $today_date=date('Y-m-d');
        $employees=DB::select("select a.*,b.in_time,b.out_time from employees a left join (select * from time_trackings where today_date=?) b on a.id=b.employee_id",[$today_date]);
        return view('admin.add_time_tracking',compact('employees'));
    }
    public function store_time_tracking(Request $request,$id)
    {
        $today_date=date('Y-m-d');
        $employee_id=$id;

        $time_tr=Time_tracking::where('employee_id',$employee_id)->where('today_date',$today_date)->get();
        if(count($time_tr)>0)
        {
            $time_trackings=Time_tracking::find($time_tr[0]->id);
        }
        else
        {
            $time_trackings=new Time_tracking();
            $time_trackings->today_date=$today_date;
            $time_trackings->employee_id=$employee_id;
        }





        if($request->input('submit_in_time'))
        {
            $in_time=$request->input('in_time');
            $request->validate([
                'in_time'=>'required'
            ]);
            $time_trackings->in_time=$in_time;
        }
        if($request->input('submit_out_time'))
        {
            $out_time=$request->input('out_time');
            $request->validate([
                'out_time'=>'required'
            ]);

            $time_trackings->out_time=$out_time;
        }


        try
        {
            $time_trackings->save();
            return redirect()->route('user.add_time_tracking')->with('success','Time tracking Added Successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.add_time_tracking')->with('error','Error to Add Time tracking');
        }
    }
    public function manage_time_tracking()
    {
        //$employees=Employee::all();
        $today_date=date('Y-m-d');
        $employees=DB::select("select a.*,b.in_time,b.out_time from employees a left join (select * from time_trackings) b on a.id=b.employee_id");
        return view('admin.manage_time_tracking',compact('employees'));
    }
}
