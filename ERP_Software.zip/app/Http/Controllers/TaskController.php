<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Task;
use Exception;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin_auth');
    }
    public function assign_employee()
    {
        $employees=Employee::all();
        return view('admin.assign_employee',compact('employees'));
    }
    public function task_assign(Request $request)
    {
        $request->validate([
            'employee_id'=>'required|regex:/^[0-9]+$/',
            'task_name'=>'required|regex:/^[a-zA-Z\s.,-]+$/',
            'task_description'=>'required|regex:/^[a-zA-Z\s.,-]+$/',
            'assign_date'=>'required|date',
            'deadline_date'=>'required|date'
        ],[
            'employee_id.required'=>'Please choose Employee name',
            'employee_id.regex'=>'Invalid Format'
        ]);

        $employee_id=$request->input('employee_id');
        $task_name=$request->input('task_name');
        $task_description=$request->input('task_description');
        $assign_date=$request->input('assign_date');
        $deadline_date=$request->input('deadline_date');
        $status="not started";

        try
        {
            Task::create([
                'employee_id'=>$employee_id,
                'task_name'=>$task_name,
                'task_description'=>$task_description,
                'assign_date'=>$assign_date,
                'deadline_date'=>$deadline_date,
                'status'=>$status
            ]);
            return redirect()->route('user.assign_employee')->with('success','Task Assigned successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.assign_employee')->with('error','Error to Assign Task');
        }
    }
    public function manage_tracking()
    {
        $tasks=Task::join("employees","tasks.employee_id","=","employees.id")->select("tasks.*","employees.employee_name")->get();
        return view('admin.manage_tracking',compact('tasks'));
    }
    public function delete_task($id)
    {
        $task=Task::find($id);

        try
        {
            $task->delete();
            return redirect()->route('user.manage_tracking')->with('success','Task Deleted successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.manage_tracking')->with('error','Error to Delete Task');
        }

    }
    public function edit_task($id)
    {
        $employees=Employee::all();
        $task=Task::find($id);
        return view('admin.edit_task',compact('employees','task'));
    }
    public function update_task(Request $request,$id)
    {
        $request->validate([
            'employee_id'=>'required|regex:/^[0-9]+$/',
            'task_name'=>'required|regex:/^[a-zA-Z\s.,-]+$/',
            'task_description'=>'required|regex:/^[a-zA-Z\s.,-]+$/',
            'assign_date'=>'required|date',
            'deadline_date'=>'required|date',
            'status'=>'required|regex:/^[a-zA-Z\s]+$/'
        ],[
            'employee_id.required'=>'Please choose Employee name',
            'employee_id.regex'=>'Invalid Format'
        ]);

        $employee_id=$request->input('employee_id');
        $task_name=$request->input('task_name');
        $task_description=$request->input('task_description');
        $assign_date=$request->input('assign_date');
        $deadline_date=$request->input('deadline_date');
        $status=$request->input('status');

        try
        {
            Task::where('id',$id)->update([
                'employee_id'=>$employee_id,
                'task_name'=>$task_name,
                'task_description'=>$task_description,
                'assign_date'=>$assign_date,
                'deadline_date'=>$deadline_date,
                'status'=>$status
            ]);
            return redirect()->route('user.manage_tracking')->with('success','Task Updated successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.manage_tracking')->with('error','Error to Update Task');
        }
    }
}
