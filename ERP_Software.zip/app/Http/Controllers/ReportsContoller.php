<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\ExpenseReport;
use App\Models\RevenueReport;
use DateTime;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportsContoller extends Controller
{
    public function __construct()
    {
        $this->middleware('admin_auth');
    }
    public function view_revenue_report()
    {
        $revenues=RevenueReport::leftJoin('clients','revenue_reports.customer_id','=','clients.id')->select('revenue_reports.*','clients.client_name')->get();
        return view('admin.view_revenue_report',compact('revenues'));
    }
    public function add_revenue()
    {
        $clients=Client::orderBy('id','asc')->get();
        return view('admin.add_revenue',['clients'=>$clients]);
    }
    public function store_revenue(Request $request)
    {
        $request->validate([
            'client_name'=>'required|regex:/^[0-9]+$/',
            'remark'=>'required|regex:/^[a-zA-Z\s\.]+$/',
            'sale_date'=>'required|date',
            'sale_amount'=>'required|numeric',
            'discount'=>'required|numeric',
            'payment_method'=>'required|regex:/^[a-zA-Z\s\.]+$/',
            'final_amount'=>'required|numeric'
        ],[
            'client_name.regex'=>'Client name not valid',
            'final_amount.numeric'=>'Please enter Numbers only'
        ]);

        try
        {
            RevenueReport::create([
                'customer_id'=>$request->input('client_name'),
                'remark'=>$request->input('remark'),
                'sale_date'=>$request->input('sale_date'),
                'sale_amount'=>$request->input('sale_amount'),
                'discount'=>$request->input('discount'),
                'payment_method'=>$request->input('payment_method'),
                'final_amount'=>$request->input('final_amount')
            ]);
            return redirect()->route('user.add_revenue')->with('success','Revenue Report Added successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.add_revenue')->with('error','Error to Add Revenue Report');
        }

    }
    public function add_expense()
    {
        return view('admin.add_expense');
    }
    public function store_expense(Request $request)
    {
        $request->validate([
            'description'=>'required|regex:/^[a-zA-Z0-9\s\.]+$/',
            'expense_date'=>'required|date',
            'expense_amount'=>'required|numeric'
        ],[
            'description.regex'=>'Description format not valid',
            'expense_amount.numeric'=>'Please enter Numbers only'
        ]);

        try
        {
            ExpenseReport::create([
                'description'=>$request->input('description'),
                'expense_date'=>$request->input('expense_date'),
                'expense_amount'=>$request->input('expense_amount')
            ]);
            return redirect()->route('user.add_expense')->with('success','Expenses Added successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.add_expense')->with('error','Error to Add Expense');
        }
    }
    public function view_expense()
    {
        $expenses=ExpenseReport::orderBy('id','desc')->get();
        return view('admin.view_expenses',compact('expenses'));
    }
    public function view_profit_and_loss(Request $request)
    {
        $choose_date=$date_wise=$month_wise=$year_wise="";
        if($choose_date=$request->input('choose_date'))
        {

            $date = new DateTime($choose_date);
            $lastDay = $date->modify('last day of this month')->format('Y-m-d');
            $firstDay = $date->modify('first day of this month')->format('Y-m-d');

            $lastDay_year = $date->modify('last day of this year')->format('Y-12-d');
            $firstDay_year = $date->modify('first day of January this year')->format('Y-m-d');


            $date_wise=DB::select("select * from (select sale_date,round(sum(final_amount),2) as income from revenue_reports where sale_date=? group by sale_date) a left join
            (SELECT round(sum(expense_amount),2) as expense_amount,expense_date,description FROM expense_reports where expense_date=? group by description,expense_date)b on a.sale_date=b.expense_date",[$choose_date,$choose_date]);

            $month_wise=DB::select("select * from (SELECT
        DATE_FORMAT(sale_date, '%Y-%m') AS month_year,
        ROUND(SUM(final_amount), 2) AS income
    FROM revenue_reports
    WHERE sale_date BETWEEN ? AND ?
    GROUP BY month_year) a left join
            (SELECT
        DATE_FORMAT(expense_date, '%Y-%m') AS month_year,
        ROUND(SUM(expense_amount), 2) AS expense_amount,
        description
    FROM expense_reports
    WHERE expense_date BETWEEN ? AND ?
    GROUP BY description, month_year)b on a.month_year=b.month_year",[$firstDay,$lastDay,$firstDay,$lastDay]);


    $year_wise = DB::select("
    SELECT
        *
    FROM (
        SELECT
            DATE_FORMAT(sale_date, '%Y') AS year,
            ROUND(SUM(final_amount), 2) AS income
        FROM revenue_reports
        WHERE sale_date BETWEEN ? AND ?
        GROUP BY year
    ) a
    LEFT JOIN (
        SELECT
            DATE_FORMAT(expense_date, '%Y') AS year,
            ROUND(SUM(expense_amount), 2) AS expense_amount,
            description
        FROM expense_reports
        WHERE expense_date BETWEEN ? AND ?
        GROUP BY description,year
    ) b ON a.year = b.year
", [$firstDay_year, $lastDay_year, $firstDay_year, $lastDay_year]);



        }
        return view('admin.view_profit_and_loss',compact('choose_date','date_wise','month_wise','year_wise'));
    }

}
