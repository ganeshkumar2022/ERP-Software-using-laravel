<?php

namespace App\Http\Controllers;

use App\Mail\ClientCommunicationEmail;
use App\Models\Client;
use App\Models\Client_project;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ClientController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin_auth');
    }
    public function add_client()
    {
        return view('admin.add_client');
    }
    public function store_client(Request $request)
    {
        $request->validate([
            'name'=>'required|regex:/^[a-zA-Z\s]+$/',
            'email'=>'required|email|unique:employees,email',
            'age'=>'required|numeric',
            'mobile'=>'required|unique:employees,mobile',
            'educational_qualification'=>'required|regex:/^[a-zA-Z\s\.]+$/',
            'how_to_know_about_me'=>'required|regex:/^[a-zA-Z\s\.]+$/'
        ],[
            'myimage.required'=>'Please choose image file',
            'age.numeric'=>'Please enter Numbers only',
            'how_to_know_about_me.regex'=>'Field format is not valid',
            'how_to_know_about_me.required'=>'Field is required'
        ]);



        $client=new Client();

        $client->client_name=$request->input('name');
        $client->email=$request->input('email');
        $client->age=$request->input('age');
        $client->mobile=$request->input('mobile');
        $client->educational_qualification=$request->input('educational_qualification');
        $client->how_to_know_about_me=$request->input('how_to_know_about_me');



        try
        {
            $client->save();
            return redirect()->route('user.add_client')->with('success','Client Added successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.add_client')->with('error','Error to Add Client Details');
        }


    }
    public function manage_client()
    {
        $clients=Client::orderBy('id','desc')->get();
        return view('admin.manage_client',compact('clients'));
    }
    public function delete_client($id)
    {

            $client=Client::find($id);

            try
            {
                $client->delete();


                return redirect()->route('user.manage_client')->with('success','Client Deleted successfully');
            }
            catch(Exception $e)
            {
                return redirect()->route('user.manage_client')->with('error','Error to Delete Client');
            }

    }
    public function edit_client($id)
    {
        $client=Client::find($id);
        return view('admin.edit_client',compact('client'));
    }
    public function update_client(Request $request,$id)
    {
        $request->validate([
            'name'=>'required|regex:/^[a-zA-Z\s]+$/',
            'email'=>'required|email|unique:employees,email,'.$id,
            'age'=>'required|numeric',
            'mobile'=>'required|unique:employees,mobile',
            'educational_qualification'=>'required|regex:/^[a-zA-Z\s\.]+$/',
            'how_to_know_about_me'=>'required|regex:/^[a-zA-Z\s\.]+$/'
        ],[
            'myimage.required'=>'Please choose image file',
            'age.numeric'=>'Please enter Numbers only',
            'how_to_know_about_me.regex'=>'Field format is not valid',
            'how_to_know_about_me.required'=>'Field is required'
        ]);



        $client=Client::find($id);

        $client->client_name=$request->input('name');
        $client->email=$request->input('email');
        $client->age=$request->input('age');
        $client->mobile=$request->input('mobile');
        $client->educational_qualification=$request->input('educational_qualification');
        $client->how_to_know_about_me=$request->input('how_to_know_about_me');



        try
        {
            $client->save();
            return redirect()->route('user.edit_client',$client->id)->with('success','Client Updated successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.edit_client',$client->id)->with('error','Error to Update Client Details');
        }
    }
    public function client_project_add()
    {
        $clients=Client::orderBy('id','asc')->get();
        return view('admin.client_project_add',compact('clients'));
    }
    public function store_client_project(Request $request)
    {
        $request->validate([
            'client_name'=>'required|regex:/^[0-9]+$/',
            'project_name'=>'required|regex:/^[a-zA-Z\s\.,-]+$/',
            'project_timeline'=>'required|date',
            'project_description'=>'required|regex:/^[a-zA-Z\s\.,-]+$/',
            'project_cost'=>'required|numeric',
            'programming_language'=>'required|regex:/^[a-zA-Z\s\.]+$/'
        ],[
            'programming_language.required'=>'Please choose programming language',
            'client_name.required'=>'Please choose client name',
            'project_cost.numeric'=>'Field format not valid'
        ]);


        $client_project=new Client_project();

        $client_project->client_id=$request->input('client_name');
        $client_project->project_name=$request->input('project_name');
        $client_project->project_timeline=$request->input('project_timeline');
        $client_project->project_description=$request->input('project_description');
        $client_project->project_cost=$request->input('project_cost');
        $client_project->programming_language=$request->input('programming_language');

        try
        {
            $client_project->save();
            return redirect()->route('user.client_project_add')->with('success','Client Project Added successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.client_project_add')->with('error','Error to Add Client Project');
        }


    }
    public function manage_client_project()
    {
        $client_projects=Client_project::join('clients','client_projects.client_id','=','clients.id')->select('clients.*','client_projects.*','client_projects.id as pid')->get();
        //$client_projects=Client_project::orderBy('id','asc')->get();
        return view('admin.manage_client_project',compact('client_projects'));
    }
    public function edit_client_project($id)
    {
        $clients=Client::orderBy('id','asc')->get();
        $client_project=Client_project::find($id);
        return view('admin.edit_client_project',compact('clients','client_project'));
    }
    public function update_client_project($id,Request $request)
    {
        $request->validate([
            'client_name'=>'required|regex:/^[0-9]+$/',
            'project_name'=>'required|regex:/^[a-zA-Z\s\.,-]+$/',
            'project_timeline'=>'required|date',
            'project_description'=>'required|regex:/^[a-zA-Z\s\.,-]+$/',
            'project_cost'=>'required|numeric',
            'programming_language'=>'required|regex:/^[a-zA-Z\s\.]+$/'
        ],[
            'programming_language.required'=>'Please choose programming language',
            'client_name.required'=>'Please choose client name',
            'project_cost.numeric'=>'Field format not valid'
        ]);


        $client_project=Client_project::find($id);

        $client_project->client_id=$request->input('client_name');
        $client_project->project_name=$request->input('project_name');
        $client_project->project_timeline=$request->input('project_timeline');
        $client_project->project_description=$request->input('project_description');
        $client_project->project_cost=$request->input('project_cost');
        $client_project->programming_language=$request->input('programming_language');

        try
        {
            $client_project->save();
            return redirect()->route('user.manage_client_project')->with('success','Client Project Updated successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.manage_client_project')->with('error','Error to Update Client Project');
        }
    }
    public function delete_client_project(Request $request,$id)
    {
        $client_project=Client_project::find($id);

        try
        {
            $client_project->delete();


            return redirect()->route('user.manage_client_project')->with('success','Client Project Deleted successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.manage_client_project')->with('error','Error to Delete Client Project');
        }
    }
    public function communication()
    {
        $clients=Client::orderBy('client_name','asc')->get();
        return view('admin.communication',compact('clients'));
    }
    public function send_email(Request $request)
    {
        $request->validate([
            'name'=>'required|regex:/^[a-zA-Z\s]+$/',
            'email'=>'required|email',
            'subject'=>'required|regex:/^[a-zA-Z\s]+$/',
            'message'=>'required|regex:/^[a-zA-Z\s\.,-]+$/'
        ],[
            'email.email'=>'Please enter a Valid Email'
        ]);

        $name = $request->input('name');
        $email=$request->input('email');
        $subject=$request->input('subject');
        $messageBody = $request->input('message');

        try
        {
            Mail::to($email)->send(new ClientCommunicationEmail($name,$messageBody,$subject));
            return redirect()->route('user.communication')->with('success','Email Sended Successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.communication')->with('error','Error to Send Email');
        }
    }
    public function ajax_get(Request $request)
    {
        $cmd=$request->input('cmd');
        if($cmd=="mail_get")
        {
            $client_name=$request->input('name');
            $client=Client::where('client_name',$client_name)->first();
            return $client->email;
        }
    }

}
