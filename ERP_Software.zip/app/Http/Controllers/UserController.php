<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Client_project;
use App\Models\Employee;
use App\Models\RevenueReport;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin_auth');
    }
    public function dashboard()
    {
        $clients_count=Client::count();
        $employees_count=Employee::count();
        $projects_count=Client_project::count();
        $revenues=RevenueReport::where('sale_date',date('Y-m-d'))->sum('final_amount');

        $date=date('Y');
        $cli_count = DB::select("
    SELECT
        COUNT(CASE WHEN MONTH(created_at) = 1 THEN 1 END) AS january_clients,
        COUNT(CASE WHEN MONTH(created_at) = 2 THEN 1 END) AS february_clients,
        COUNT(CASE WHEN MONTH(created_at) = 3 THEN 1 END) AS march_clients,
        COUNT(CASE WHEN MONTH(created_at) = 4 THEN 1 END) AS april_clients,
        COUNT(CASE WHEN MONTH(created_at) = 5 THEN 1 END) AS may_clients,
        COUNT(CASE WHEN MONTH(created_at) = 6 THEN 1 END) AS june_clients,
        COUNT(CASE WHEN MONTH(created_at) = 7 THEN 1 END) AS july_clients,
        COUNT(CASE WHEN MONTH(created_at) = 8 THEN 1 END) AS august_clients,
        COUNT(CASE WHEN MONTH(created_at) = 9 THEN 1 END) AS september_clients,
        COUNT(CASE WHEN MONTH(created_at) = 10 THEN 1 END) AS october_clients,
        COUNT(CASE WHEN MONTH(created_at) = 11 THEN 1 END) AS november_clients,
        COUNT(CASE WHEN MONTH(created_at) = 12 THEN 1 END) AS december_clients
    FROM
        clients
    WHERE
        YEAR(created_at) = ?
", [$date]);


$rev_count=DB::select("
SELECT
    SUM(CASE WHEN MONTH(sale_date) = 1 THEN final_amount else 0 END) AS january_clients,
    SUM(CASE WHEN MONTH(sale_date) = 2 THEN final_amount else 0 END) AS february_clients,
    SUM(CASE WHEN MONTH(sale_date) = 3 THEN final_amount else 0 END) AS march_clients,
    SUM(CASE WHEN MONTH(sale_date) = 4 THEN final_amount else 0 END) AS april_clients,
    SUM(CASE WHEN MONTH(sale_date) = 5 THEN final_amount else 0 END) AS may_clients,
    SUM(CASE WHEN MONTH(sale_date) = 6 THEN final_amount else 0 END) AS june_clients,
    SUM(CASE WHEN MONTH(sale_date) = 7 THEN final_amount else 0 END) AS july_clients,
    SUM(CASE WHEN MONTH(sale_date) = 8 THEN final_amount else 0 END) AS august_clients,
    SUM(CASE WHEN MONTH(sale_date) = 9 THEN final_amount else 0 END) AS september_clients,
    SUM(CASE WHEN MONTH(sale_date) = 10 THEN final_amount else 0 END) AS october_clients,
    SUM(CASE WHEN MONTH(sale_date) = 11 THEN final_amount else 0 END) AS november_clients,
    SUM(CASE WHEN MONTH(sale_date) = 12 THEN final_amount else 0 END) AS december_clients
FROM
    revenue_reports
WHERE
    YEAR(sale_date) = ?
", [$date]);

        if(!session()->has('user_data'))
        {
        $id=session('uid');
        $user=User::find($id);
        session()->put('user_data',$user);
        }
        return view('admin/index',compact('clients_count','employees_count','projects_count','revenues','cli_count','rev_count'));
    }
    public function view_profile()
    {
        $id=session('uid');
        $user=User::find($id);
        return view('admin.profile',compact('user'));
    }
    public function update_profile(Request $request)
    {
        $request->validate([
            'name'=>'required|regex:/^[a-zA-Z\s]+$/',
            'email'=>'required|email',
            'myimage'=>'image|max:2048'
        ],[
            'myimage.image'=>'Please upload image files only'
        ]);

        $id=session('uid');
        $user=User::find($id);

        $user->name=$request->input('name');
        $user->email=$request->input('email');

        if($files=$request->file('myimage'))
        {
            if($user->profile_image==null)
            {

            }
            else
            {
            $file_path=public_path("profile/".$user->profile_image);
            if(file_exists($file_path))
            {
                unlink($file_path);
            }
            }

            $name=rand(1000000,9999999)."_profile.".$files->getClientOriginalExtension();
            $files->move('profile',$name);
            $user->profile_image=$name;
        }

        try
        {
            $user->save();
            session()->put('user_data',$user);
            return redirect()->route('user.view_profile')->with('success','Profile Updated successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.view_profile')->with('error','Error to Update Profile');
        }


    }
    public function update_password()
    {
        return view('admin.update_password');
    }
    public function change_password(Request $request)
    {
        $request->validate([
            'password'=>'min:3|required|regex:/^[a-zA-Z0-9$#@._]+$/'
        ]);

        $password=$request->input('password');

        $id=session('uid');
        $user=User::find($id);
        $user->password=password_hash($password,PASSWORD_DEFAULT);
        try
        {
            $user->save();
            return redirect()->route('user.update_password')->with('success','Password Updated Successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.update_password')->with('error','Error to Update Password');
        }
    }
    public function logout()
    {
        session()->forget('uid');
        return redirect('/');
    }

}
