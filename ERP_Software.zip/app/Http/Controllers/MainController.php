<?php

namespace App\Http\Controllers;

use App\Mail\ClientCommunicationEmail;
use App\Models\ForgotPassword_model;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Mail;

class MainController extends Controller
{
    public function home()
    {
        return view('home');
    }
    public function forgot_password()
    {
        return view('forgot_password');
    }
    public function new_password_create()
    {
        if(Cookie::has('fp_email'))
        {
           return view('new_password_create');
        }
        else
        {
            return view('forgot_password');
        }
    }
    public function otp_verify(Request $request)
    {
        if(Cookie::has('fp_email'))
        {
        $request->validate([
            'otp'=>'required|numeric|regex:/^[0-9]+$/'
        ]);
        $email=Cookie::get('fp_email');
        $otp=$request->input('otp');
        $get_otp=ForgotPassword_model::where('email',$email)->value('otp');
        if($otp==$get_otp)
        {
            ForgotPassword_model::where('email',$email)->update(['verified_status'=>'Y']);
            return redirect()->route('main.password_new')->with('flash_alert','OTP Verified');
        }
        else
        {
            return redirect()->route('main.new_password_create')->with('error','OTP incorrect');
        }

        }
    }
    public function password_new()
    {
        if(Cookie::has('fp_email'))
        {
           return view('password_new');
        }
        else
        {
            return view('forgot_password');
        }
    }
    public function password_new_backend(Request $request)
    {
        if(Cookie::has('fp_email'))
        {
            $request->validate([
                'password'=>'required|regex:/^[a-zA-Z0-9$#@._]+$/'
            ]);

            $email=Cookie::get('fp_email');
            $password=$request->input('password');

            $data=User::where('email',$email)->first();
            $data->password=password_hash($password,PASSWORD_DEFAULT);
            try
            {
            $data->save();
            Cookie::queue(Cookie::forget('fp_email'));
            return redirect()->back()->with('success','Password Changed successfully');
            }
            catch(Exception $e)
            {
                return redirect()->back()->with('error','Error to Update password');
            }
        }
        else
        {
            return view('forgot_password');
        }
    }
    public function check_forgot_password(Request $request)
    {
        $request->validate([
            'email'=>'required|email|regex:/^[a-zA-Z0-9$#@._]+$/'
        ]);

        $email=$request->input('email');

        $user=User::where('email',$email)->first();
        if($user)
        {

            $otp=rand(1000,9999);
            $name=$user->name;
            $subject="OTP Verficiation";
            $messageBody="Your OTP is ".$otp;
            try
            {
            ForgotPassword_model::where('email',$email)->delete();
            ForgotPassword_model::create(['email'=>$email,"otp"=>$otp]);
            Cookie::queue('fp_email',$email,10);
            Mail::to($email)->send(new ClientCommunicationEmail($name,$messageBody,$subject));
            return redirect()->route('main.new_password_create')->with('flash_alert','Email sent successfully');
            }
            catch(Exception $e)
            {
                return redirect()->route('main.forgot_password')->with('error','Error Occurs');
            }
        }
        else
        {
            return redirect()->route('main.forgot_password')->with('error','Email incorrect');
        }
    }
    public function login_backend(Request $request)
    {
        $request->validate([
            'email'=>'required|email|regex:/^[a-zA-Z0-9$#@._]+$/',
            'password'=>'required|regex:/^[a-zA-Z0-9$#@._]+$/'
        ]);

        $email=$request->input('email');
        $password=$request->input('password');

        $user=User::where('email',$email)->first();
        if($user)
        {
            session()->put('uid',$user->id);
            if(password_verify($password,$user->password))
            {
                return redirect()->route('user.dashboard');
            }
            else
            {
                return redirect()->route('main.home')->with('error','Email or password incorrect');
            }
        }
        else
        {
            return redirect()->route('main.home')->with('error','Email or password incorrect');
        }

    }
    public function privacy_policy()
    {
        return view('admin.privacy_policy');
    }
    public function terms_and_conditions()
    {
        return view('admin.terms_and_conditions');
    }
}
