<?php

namespace App\Http\Controllers;

use App\Models\Add_role;
use App\Models\Employee;
use App\Models\Roles;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class EmployeeController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin_auth');
    }
    public function add_employee()
    {
        return view('admin.add_employee');
    }
    public function store_employe(Request $request)
    {
        $request->validate([
            'name'=>'required|regex:/^[a-zA-Z\s]+$/',
            'email'=>'required|email|unique:employees,email',
            'myimage'=>'required|image|max:2048',
            'age'=>'required|numeric',
            'mobile'=>'required|unique:employees,mobile',
            'educational_qualification'=>'required|regex:/^[a-zA-Z\s\.]+$/',
            'password'=>'required'
        ],[
            'myimage.required'=>'Please choose image file',
            'myimage.image'=>'Please upload image files only',
            'age.numeric'=>'Please enter Numbers only'
        ]);

        $emp=Employee::all();
        $count=count($emp)+1000+1;

        $employee=new Employee();

        $employee->employee_id="18NMJK".$count;
        $employee->employee_name=$request->input('name');
        $employee->email=$request->input('email');
        $employee->age=$request->input('age');
        $employee->mobile=$request->input('mobile');
        $employee->educational_qualification=$request->input('educational_qualification');
        $employee->password=password_hash($request->input('password'),PASSWORD_DEFAULT);

        if($files=$request->file('myimage'))
        {
            $name=rand(1000000,9999999)."_employee_profile.".$files->getClientOriginalExtension();
            $files->move('employee_profile',$name);
            $employee->profile_image=$name;
        }

        try
        {
            $employee->save();
            return redirect()->route('user.add_employee')->with('success','Employee Added successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.add_employee')->with('error','Error to Add Employee Details');
        }


    }
    public function manage_employee()
    {
        $employees=Employee::orderBy('id','desc')->get();
        return view('admin.manage_employee',compact('employees'));
    }
    public function edit_employee($id)
    {
        $employee=Employee::where('id',$id)->first();
        return view('admin.edit_employee',compact('employee'));
    }
    public function update_employee($eid,Request $request)
    {
        $request->validate([
            'name'=>'required|regex:/^[a-zA-Z\s]+$/',
            'email'=>'required|email|unique:employees,email,'.$eid,
            'myimage'=>'image|max:2048',
            'age'=>'required|numeric',
            'mobile'=>'required|unique:employees,mobile,'.$eid,
            'educational_qualification'=>'required|regex:/^[a-zA-Z\s\.]+$/'
        ],[
            'myimage.required'=>'Please choose image file',
            'myimage.image'=>'Please upload image files only',
            'age.numeric'=>'Please enter Numbers only'
        ]);


        $employee=Employee::where("id",$eid)->first();

        $employee->employee_name=$request->input('name');
        $employee->email=$request->input('email');
        $employee->age=$request->input('age');
        $employee->mobile=$request->input('mobile');
        $employee->educational_qualification=$request->input('educational_qualification');

        if($files=$request->file('myimage'))
        {

            //delete existing start
            $filePath=public_path('employee_profile/'.$employee->profile_image);
            if(File::exists($filePath))
            {
                File::delete($filePath);
            }
            //delete existing end

            $name=rand(1000000,9999999)."_employee_profile.".$files->getClientOriginalExtension();
            $files->move('employee_profile',$name);
            $employee->profile_image=$name;

        }

        try
        {
            $employee->save();
            return redirect()->route('user.edit_employee',$employee->id)->with('success','Employee Updated successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.edit_employee',$employee->id)->with('error','Error to Updated Employee Details');
        }
    }
    public function delete_employee($id)
    {

            $employee=Employee::find($id);

            try
            {
                $employee->delete();

                //delete existing start
            $filePath=public_path('employee_profile/'.$employee->profile_image);
            if(File::exists($filePath))
            {
                File::delete($filePath);
            }
            //delete existing end

                return redirect()->route('user.manage_employee',$employee->id)->with('success','Employee Deleted successfully');
            }
            catch(Exception $e)
            {
                return redirect()->route('user.manage_employee',$employee->id)->with('error','Error to Delete Employee');
            }

    }
    public function assign_roles()
    {
        $employees=DB::select("select * from employees where id not in (select employee_id from add_roles)");
        $roles=Roles::all();
        return view('admin.assign_roles',compact('employees','roles'));
    }
    public function view_roles()
    {
        $roles=DB::select("select a.*,c.role_name,b.employee_name,b.employee_id as emp_id from add_roles a left join employees b on a.employee_id=b.id left join roles c on c.id=a.role_id");
        return view('admin.view_roles',['roles'=>$roles]);
    }
    public function delete_roles($id)
    {

            $employee=Add_role::find($id);

            try
            {
                $employee->delete();

                return redirect()->route('user.view_roles')->with('success','Roles Deleted successfully');
            }
            catch(Exception $e)
            {
                return redirect()->route('user.view_roles')->with('error','Error to Delete Roles');
            }
    }
    public function add_roles(Request $request)
    {
        $request->validate([
            'employee_name'=>'required|regex:/^\d+$/',
            'role'=>'required|regex:/^\d+$/',
            'salary'=>'required|regex:/^\d+$/'
        ],[
            'employee_name.required'=>'Please choose Employee name',
            'role.required'=>'Please choose Employee Role',
            'salary.required'=>'Please Enter Salary Field'
        ]);

        $employee_id=$request->input('employee_name');
        $role=$request->input('role');
        $salary=$request->input('salary');

        try
        {
            Add_role::create([
                'employee_id'=>$employee_id,
                'role_id'=>$role,
                'salary'=>$salary
            ]);
            return redirect()->route('user.assign_roles')->with('success','Roles Assigned Successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('user.assign_roles')->with('error','Error to Assign Roles');
        }
    }

}
