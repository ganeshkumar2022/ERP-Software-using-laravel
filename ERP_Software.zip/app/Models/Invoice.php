<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    use HasFactory;
    protected $fillable=['invoice_no','invoice_date','employee_name','employee_id','department','position','pay_period_from','pay_period_to','total_working_days','present_days','gross_pay','tax','health_insurance','retirement','total_deduction','net_pay'];
}
