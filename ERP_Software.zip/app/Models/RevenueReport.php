<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RevenueReport extends Model
{
    use HasFactory;
    protected $fillable=['customer_id','remark','sale_date','sale_amount','payment_method','discount','final_amount'];
}
