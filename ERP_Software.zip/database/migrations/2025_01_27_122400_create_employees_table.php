<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('employee_id');
            $table->string('employee_name',50);
            $table->integer('age');
            $table->string('email',100);
            $table->char('mobile',10);
            $table->string('educational_qualification');
            $table->string('password')->default('$2y$10$e4YhOsmIcqH2XhjzD9gNNuzWV0w4N2EzD0hwgLf4oVwWLJ3g5N23G');
            $table->string('profile_image')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('employees');
    }
};
