<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->integer('invoice_no');
            $table->date('invoice_date');
            $table->string('employee_name',100);
            $table->string('employee_id',100);
            $table->string('department',100);
            $table->string('position',100);
            $table->date('pay_period_from');
            $table->date('pay_period_to');
            $table->integer('total_working_days');
            $table->integer('present_days');
            $table->integer('gross_pay');
            $table->integer('tax');
            $table->integer('health_insurance');
            $table->integer('retirement');
            $table->integer('total_deduction');
            $table->integer('net_pay');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('invoices');
    }
};
