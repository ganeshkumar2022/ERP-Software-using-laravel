<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('revenue_reports', function (Blueprint $table) {
            $table->bigIncrements('sale_id');
            $table->integer('customer_id');
            $table->text('remark');
            $table->date('sale_date');
            $table->decimal('sale_amount',10,2);
            $table->string('payment_method',50);
            $table->integer('discount');
            $table->decimal('final_amount',10,2);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('revenue_reports');
    }
};
