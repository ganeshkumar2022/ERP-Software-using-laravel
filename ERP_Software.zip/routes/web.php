<?php

use App\Http\Controllers\ClientController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\ERP_installController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\MainController;
use App\Http\Controllers\ReportsContoller;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\TimeTrackingController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;
use Symfony\Component\Routing\Route as RoutingRoute;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

//erp install start
Route::group(['as'=>'erp_install.'],function(){

Route::get("/step1",[ERP_installController::class,"index"])->name('step1');
Route::post("/purchase_check",[ERP_installController::class,"purchase_check"])->name('step1_check');
Route::get("/step2",[ERP_installController::class,"step2"])->name('step2');
Route::get("/step3",[ERP_installController::class,"step3"])->name('step3');
Route::post("/step3_backend",[ERP_installController::class,"step3_backend"])->name('step3_backend');
Route::get("/step4",[ERP_installController::class,"step4"])->name('step4');
Route::post("/step4_backend",[ERP_installController::class,"step4_backend"])->name('step4_backend');
Route::get("/step5",[ERP_installController::class,"step5"])->name('step5');
});
//erp install end


//main content start
Route::group(['as'=>'main.'],function(){

Route::get("/",[MainController::class,"home"])->name('home');
Route::get("/forgot_password",[MainController::class,"forgot_password"])->name('forgot_password');
Route::get("/new_password_create",[MainController::class,"new_password_create"])->name('new_password_create');
Route::post("/check_forgot_password",[MainController::class,"check_forgot_password"])->name('check_forgot_password');
Route::post("/login_backend",[MainController::class,"login_backend"])->name('login_backend');
Route::get("/privacy_policy",[MainController::class,"privacy_policy"])->name('privacy_policy');
Route::get("/terms_and_conditions",[MainController::class,"terms_and_conditions"])->name('terms_and_conditions');
Route::post("/otp_verify",[MainController::class,"otp_verify"])->name('otp_verify');
Route::get("/password_new",[MainController::class,"password_new"])->name('password_new');
Route::post("/password_new_backend",[MainController::class,"password_new_backend"])->name('password_new_backend');
});
//main content end

//user content start
Route::group(['as'=>'user.','prefix'=>'admin'],function(){

//profile,update password start
Route::get("dashboard",[UserController::class,"dashboard"])->name('dashboard');
Route::get("view_profile",[UserController::class,"view_profile"])->name('view_profile');
Route::post("update_profile",[UserController::class,"update_profile"])->name('update_profile');
Route::get("update_password",[UserController::class,"update_password"])->name('update_password');
Route::patch("change_password",[UserController::class,"change_password"])->name('change_password');
Route::get("logout",[UserController::class,"logout"])->name('logout');
//profile,update password end

//employee start
Route::get("add_employee",[EmployeeController::class,"add_employee"])->name('add_employee');
Route::post("employee_store",[EmployeeController::class,"store_employe"])->name('store_employee');
Route::get("manage_employee",[EmployeeController::class,"manage_employee"])->name('manage_employee');
Route::get("edit_employee/{id}",[EmployeeController::class,"edit_employee"])->name('edit_employee');
Route::put("update_employee/{eid}",[EmployeeController::class,"update_employee"])->name('update_employee');
Route::delete("delete_employee/{id}",[EmployeeController::class,"delete_employee"])->name('delete_employee');
Route::get("assign_roles",[EmployeeController::class,"assign_roles"])->name('assign_roles');
Route::post("add_roles",[EmployeeController::class,"add_roles"])->name('add_roles');
Route::get("view_roles",[EmployeeController::class,"view_roles"])->name('view_roles');
Route::delete("delete_roles/{id}",[EmployeeController::class,"delete_roles"])->name('delete_roles');
//employee end

//client start
Route::get("add_client",[ClientController::class,"add_client"])->name('add_client');
Route::post("store_client",[ClientController::class,"store_client"])->name('store_client');
Route::get("manage_client",[ClientController::class,"manage_client"])->name('manage_client');
Route::delete("delete_client/{id}",[ClientController::class,"delete_client"])->name('delete_client');
Route::get("edit_client/{id}",[ClientController::class,"edit_client"])->name('edit_client');
Route::put("update_client/{id}",[ClientController::class,"update_client"])->name('update_client');
Route::get("add_project_client",[ClientController::class,"client_project_add"])->name('client_project_add');
Route::post("client_project_store",[ClientController::class,"store_client_project"])->name('store_client_project');
Route::get("manage_client_project",[ClientController::class,"manage_client_project"])->name('manage_client_project');
Route::get("edit_client_project/{id}",[ClientController::class,"edit_client_project"])->name('edit_client_project');
Route::put("update_client_project/{id}",[ClientController::class,"update_client_project"])->name('update_client_project');
Route::delete("delete_client_project/{id}",[ClientController::class,"delete_client_project"])->name('delete_client_project');
Route::get("communication",[ClientController::class,"communication"])->name('communication');
Route::post("send_email",[ClientController::class,"send_email"])->name('send_mail');
Route::post("some_ajax_get",[ClientController::class,"ajax_get"])->name('ajax_get');
Route::get("assign_employee",[TaskController::class,"assign_employee"])->name('assign_employee');
Route::post("task_assign",[TaskController::class,"task_assign"])->name('task_assign');
Route::get("manage_tracking",[TaskController::class,"manage_tracking"])->name('manage_tracking');
Route::delete("delete_task/{id}",[TaskController::class,"delete_task"])->name('delete_task');
Route::get("edit_task/{id}",[TaskController::class,"edit_task"])->name('edit_task');
Route::put('update_task/{id}',[TaskController::class,"update_task"])->name('update_task');
Route::get("add_time_tracking",[TimeTrackingController::class,"time_tracking"])->name('add_time_tracking');
Route::post("store_time_tracking/{id}",[TimeTrackingController::class,"store_time_tracking"])->name('store_time_tracking');

Route::get("manage_time_tracking",[TimeTrackingController::class,"manage_time_tracking"])->name('manage_time_tracking');
Route::get("invoice_create",[InvoiceController::class,"invoice_create"])->name('invoice_create');
Route::post("store_invoice",[InvoiceController::class,"store_invoice"])->name('store_invoice');
Route::post("get_employee_data",[InvoiceController::class,"get_employee_data"])->name('get_employee_data');
Route::get("manage_invoice",[InvoiceController::class,"manage_invoice"])->name('manage_invoice');
Route::get("view_invoice/{id}",[InvoiceController::class,"view_invoice"])->name('view_invoice');
Route::get("view_revenue_report",[ReportsContoller::class,"view_revenue_report"])->name('view_revenue_report');
Route::get("add_revenue",[ReportsContoller::class,"add_revenue"])->name('add_revenue');
Route::post("store_revenue",[ReportsContoller::class,"store_revenue"])->name('store_revenue');
Route::get("add_expense",[ReportsContoller::class,"add_expense"])->name('add_expense');
Route::post("store_expense",[ReportsContoller::class,"store_expense"])->name('store_expense');
Route::get("view_expense",[ReportsContoller::class,"view_expense"])->name('view_expense');
Route::get("profit_and_loss",[ReportsContoller::class,"view_profit_and_loss"])->name('view_profit_and_loss');
//client end



});
//user content end
