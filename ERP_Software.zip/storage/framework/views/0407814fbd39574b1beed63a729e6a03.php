<?php $__env->startSection('title','ERP Software - Edit Employee'); ?>

<?php $__env->startSection('main-content'); ?>

        <div id="layoutSidenav">
          <?php echo $__env->make('layout.admin_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Employee</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / Edit Employee</li>
                        </ol>
                        <div class="row">

                            <!-- add employee content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-7">
                                <!-- alert show start -->
                                <?php if(session('success')): ?>
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> <?php echo e(session('error')); ?>

                                </div>
                                <?php endif; ?>
                                <!-- alert show end -->
                                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">Edit Employee</h3></div>
                                                        <div class="card-body">
                                                            <form method="post" enctype="multipart/form-data" autocomplete="off" action="<?php echo e(route('user.update_employee',$employee->id)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="name" value="<?php echo e($employee->employee_name); ?>" name="name" type="text" placeholder="Enter your  Name" />
                                                                            <label for="name">Name</label>
                                                                        </div>
                                                                        <?php if($errors->has('name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="email" name="email" value="<?php echo e($employee->email); ?>" type="text" placeholder="Enter your Email" />
                                                                            <label for="email">Email</label>
                                                                        </div>
                                                                        <?php if($errors->has('email')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="age" onkeypress="return number_check(event)" name="age" type="text" value="<?php echo e($employee->age); ?>" placeholder="Enter your age" />
                                                                            <label for="age">Age</label>
                                                                        </div>
                                                                        <?php if($errors->has('age')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('age')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="mobile" name="mobile" type="text" placeholder="Enter your mobile no" onkeypress="return number_check(event)" maxlength="10" value="<?php echo e($employee->mobile); ?>" />
                                                                            <label for="mobile">Mobile</label>
                                                                        </div>
                                                                        <?php if($errors->has('mobile')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('mobile')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>

                                                                <div class="row mb-3">
                                                                    <div class="col-md-12">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="educational_qualification" name="educational_qualification" value="<?php echo e($employee->educational_qualification); ?>" type="text" placeholder="Enter Educational Qualification" />
                                                                            <label for="educational_qualification">Educational Qualification</label>
                                                                        </div>
                                                                        <?php if($errors->has('educational_qualification')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('educational_qualification')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>

                                                                <div class=" mb-3">

                                                                    <input class="form-control form-control-lg mt-3" accept="image/*" id="myimage" name="myimage" type="file" />
                                                                    <?php if($errors->has('myimage')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('myimage')); ?></span>
                                    <?php endif; ?>
                                                                </div>
                                                                <div class="mt-4 mb-0">
                                                                    <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Update</button></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>
<script>
    function number_check(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
</script>
                            <!-- add employee content end -->

                        </div>


                    </div>
                </main>
                <?php echo $__env->make('layout.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
       <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\ERP_Software\resources\views/admin/edit_employee.blade.php ENDPATH**/ ?>