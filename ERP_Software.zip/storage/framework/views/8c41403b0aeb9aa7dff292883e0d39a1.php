<?php $__env->startSection('title','ERP Software - Client Project Edit'); ?>

<?php $__env->startSection('main-content'); ?>

        <div id="layoutSidenav">
          <?php echo $__env->make('layout.admin_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Client Project</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / Client Project Edit</li>
                        </ol>
                        <div class="row">

                            <!-- add employee content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-7">
                                <!-- alert show start -->
                                <?php if(session('success')): ?>
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> <?php echo e(session('error')); ?>

                                </div>
                                <?php endif; ?>
                                <!-- alert show end -->
                                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">Client Project Edit</h3></div>
                                                        <div class="card-body">
                                                            <form method="post" autocomplete="off" action="<?php echo e(route('user.update_client_project',$client_project->id)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <select class="form-select" name="client_name" id="client_name">
                                                                                <option value="">Choose Client Name</option>
                                                                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($client->id); ?>"  <?php echo e($client_project->client_id==$client->id ? 'selected' : ''); ?>><?php echo e($client->client_name); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                            <label for="client_name">Client Name</label>
                                                                        </div>
                                                                        <?php if($errors->has('client_name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('client_name')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="project_name" name="project_name" value="<?php echo e($client_project->project_name); ?>" type="text" placeholder="Enter your Email" />
                                                                            <label for="project_name">Project Name</label>
                                                                        </div>
                                                                        <?php if($errors->has('project_name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('project_name')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="project_timeline" name="project_timeline" type="date" value="<?php echo e($client_project->project_timeline); ?>" placeholder="Enter your age" />
                                                                            <label for="project_timeline">Project_timeline</label>
                                                                        </div>
                                                                        <?php if($errors->has('project_timeline')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('project_timeline')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="project_description" placeholder="Enter project Description" name="project_description" type="text" value="<?php echo e($client_project->project_description); ?>" />
                                                                            <label for="project_description">Project Description</label>
                                                                        </div>
                                                                        <?php if($errors->has('project_description')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('project_description')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>

                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="project_cost" name="project_cost" value="<?php echo e($client_project->project_cost); ?>" type="text" onkeypress="return number_check(event)" maxlength="10" placeholder="Enter project Cost" />
                                                                            <label for="project_cost">Project Cost</label>
                                                                        </div>
                                                                        <?php if($errors->has('project_cost')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('project_cost')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <select class="form-select" name="programming_language" id="programming_language">
                                                                                <option value="">Choose Programming Languages</option>
                                                                                <option value="PHP" <?php echo e($client_project->programming_language=='PHP' ? 'selected' : ''); ?>>PHP</option>
                                                                                <option value="Java" <?php echo e($client_project->programming_language=='Java' ? 'selected' : ''); ?>>Java</option>
                                                                                <option value="Python" <?php echo e($client_project->programming_language=='Python' ? 'selected' : ''); ?>>Python</option>
                                                                            </select>
                                                                            <label for="programming_language">Programming Language</label>
                                                                        </div>
                                                                        <?php if($errors->has('programming_language')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('programming_language')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>


                                                                <div class="mt-4 mb-0">
                                                                    <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Update</button></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>
<script>
    function number_check(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
</script>
                            <!-- add employee content end -->

                        </div>


                    </div>
                </main>
                <?php echo $__env->make('layout.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
       <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\ERP_Software\resources\views/admin/edit_client_project.blade.php ENDPATH**/ ?>