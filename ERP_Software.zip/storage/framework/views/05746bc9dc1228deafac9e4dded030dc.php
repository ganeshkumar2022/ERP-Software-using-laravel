<?php $__env->startSection('title','ERP Software - Add Revenue'); ?>

<?php $__env->startSection('main-content'); ?>

        <div id="layoutSidenav">
          <?php echo $__env->make('layout.admin_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Revenue</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / View Revenue / Add Revenue</li>
                        </ol>
                        <div class="row">

                            <!-- add employee content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-7">
                                <!-- alert show start -->
                                <?php if(session('success')): ?>
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> <?php echo e(session('error')); ?>

                                </div>
                                <?php endif; ?>
                                <!-- alert show end -->
                                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">Add Revenue</h3></div>
                                                        <div class="card-body">
                                                            <form method="post" autocomplete="off" action="<?php echo e(route('user.store_revenue')); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <select class="form-select" name="client_name" id="client_name">
                                                                                <option value="">Choose Client Name</option>
                                                                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($client->id); ?>"  <?php echo e(old('client_name')==$client->id ? 'selected' : ''); ?>><?php echo e($client->client_name); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                            <label for="client_name">Client Name</label>
                                                                        </div>
                                                                        <?php if($errors->has('client_name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('client_name')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="remark" name="remark" value="<?php echo e(old('remark')); ?>" type="text" placeholder="Enter your remark" />
                                                                            <label for="remark">Remark</label>
                                                                        </div>
                                                                        <?php if($errors->has('remark')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('remark')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="sale_date" name="sale_date" type="date" value="<?php echo e(old('sale_date')); ?>" placeholder="Entersale date" />
                                                                            <label for="sale_date">Sale date</label>
                                                                        </div>
                                                                        <?php if($errors->has('sale_date')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('sale_date')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="sale_amount" name="sale_amount" value="<?php echo e(old('sale_amount')); ?>" type="text" onkeypress="return number_check(event)" maxlength="10" placeholder="Enter Sale Amount" />
                                                                            <label for="sale_amount">Sale Amount</label>
                                                                        </div>
                                                                        <?php if($errors->has('sale_amount')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('sale_amount')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>

                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input onkeyup="final_amount_find(this.value)" class="form-control" id="discount" name="discount" value="<?php echo e(old('discount')); ?>" type="text" onkeypress="return number_check(event)" maxlength="10" placeholder="Enter Discount" />
                                                                            <label for="discount">Discount (%)</label>
                                                                        </div>
                                                                        <?php if($errors->has('discount')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('discount')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <select class="form-select" name="payment_method" id="payment_method">
                                                                                <option value="">Choose Payment method</option>
                                                                                <option value="Net Banking" <?php echo e(old('payment_method')=='Net Banking' ? 'selected' : ''); ?>>Net Banking</option>
                                                                                <option value="UPI" <?php echo e(old('payment_method')=='UPI' ? 'selected' : ''); ?>>UPI</option>
                                                                                <option value="Cash" <?php echo e(old('payment_method')=='Cash' ? 'selected' : ''); ?>>Cash</option>
                                                                            </select>
                                                                            <label for="payment_method">Payment Method</label>
                                                                        </div>
                                                                        <?php if($errors->has('payment_method')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('payment_method')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input readonly class="form-control" id="final_amount" name="final_amount" value="<?php echo e(old('final_amount')); ?>" type="text" onkeypress="return number_check(event)" maxlength="10" placeholder="Enter Final Amount" />
                                                                            <label for="final_amount">Final Amount</label>
                                                                        </div>
                                                                        <?php if($errors->has('final_amount')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('final_amount')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>


                                                                <div class="mt-4 mb-0">
                                                                    <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Add</button></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>
<script>
    function number_check(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
    function final_amount_find(discount)
    {
        var sale_amount=$("#sale_amount").val();
        if(sale_amount!="" && sale_amount>0 && discount<=30)
        {
            discount_amount=sale_amount*(discount/100);
            final_amount=sale_amount-discount_amount;
            $("#final_amount").val(final_amount);
        }
    }
</script>
                            <!-- add employee content end -->

                        </div>


                    </div>
                </main>
                <?php echo $__env->make('layout.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
       <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/admin/add_revenue.blade.php ENDPATH**/ ?>