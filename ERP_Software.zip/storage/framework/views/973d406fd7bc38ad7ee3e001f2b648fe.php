<?php $__env->startSection('title','ERP Software - Erp install step 3'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="main-erp-install-3-page">
<div class="container">
    <h1 class="text-center my-3">ERP Software Installer</h1>
    <div class="card shadow">
        <div class="card-body">
            <div class="mycontent my-3">
                <table class="table table-borderless">
                    <tr>
                        <td align="center">
                            <div class="m-one rounded py-3 position-relative bg-light border">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>1.</h1>
                            <span>Step One</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 position-relative rounded bg-light border">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>2.</h1>
                            <span>Step Two</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 main-ins-active rounded">
                            <h1>3.</h1>
                            <span>Step Three</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>4.</h1>
                            <span>Step Four</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>5.</h1>
                            <span>Step Five</span>
                            </div>
                        </td>
                    </tr>
                </table>
                <hr style="background-color:gray;height:6px;">
                <!-- step 3 content start -->
                <div class="step-3-content">
                    <h3><span class="main-ins-active rounded-5 d-inline-block ps-3 pt-2" style="height:50px;width:50px;">3</span> Step Three</h3>

<!-- database start -->
<div class="card my-2 shadow-sm">
<div class="card-body">
     <!-- form content start -->
     <form action="<?php echo e(route('erp_install.step3_backend')); ?>" id="step3_form" method="post" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="mb-3 mt-3">
          <label for="dbname" class="form-label fw-bold">Database Name:</label>
          <input type="text" class="form-control" id="dbname" placeholder="Enter Database name" name="dbname">
        </div>
        <?php if($errors->has('dbname')): ?>
        <span class="text-danger"><?php echo e($errors->first('dbname')); ?></span>
      <?php endif; ?>
        <div class="">
          <label for="username" class="form-label fw-bold">Username:</label>
          <input type="text" class="form-control" id="username" placeholder="Enter Username" name="username">
        </div>
        <?php if($errors->has('username')): ?>
        <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
      <?php endif; ?>
        <div class="">
            <label for="password" class="form-label fw-bold">Password:</label>
            <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
          </div>
          <?php if($errors->has('password')): ?>
          <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
        <?php endif; ?>
          <div class="">
            <label for="hostname" class="form-label fw-bold">Host Name: <i class="fa-solid fa-circle-question"></i></label>
            <input type="text" class="form-control" id="hostname" placeholder="Enter Host name" name="hostname">
          </div>
          <?php if($errors->has('hostname')): ?>
          <span class="text-danger"><?php echo e($errors->first('hostname')); ?></span>
        <?php endif; ?>
      </form>
     <!-- form content end -->
</div>
</div>
<!-- database end -->



<a href="<?php echo e(route('erp_install.step2')); ?>" class="btn btn-success main-ins-active border-green btn-lg rounded-1 float-start my-3 px-5">Previous</a>

<button type="submit" form="step3_form" class="btn btn-success main-ins-active border-green btn-lg rounded-1 float-end my-3 px-5">Next</button>
                </div>
                <!-- step 3 content end -->
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/erp_install/step3.blade.php ENDPATH**/ ?>