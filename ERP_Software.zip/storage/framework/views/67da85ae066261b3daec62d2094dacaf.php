<?php $__env->startSection('title','ERP Software - Erp install step 5'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="main-erp-install-3-page">
<div class="container">
    <h1 class="text-center my-3">ERP Software Installer</h1>
    <div class="card shadow">
        <div class="card-body">
            <div class="mycontent my-3">
                <table class="table table-borderless">
                    <tr>
                        <td align="center">
                            <div class="m-one rounded py-3 position-relative bg-light border">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>1.</h1>
                            <span>Step One</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 position-relative rounded bg-light border">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>2.</h1>
                            <span>Step Two</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3  position-relative rounded bg-light border">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>3.</h1>
                            <span>Step Three</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded bg-light border position-relative">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>4.</h1>
                            <span>Step Four</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 main-ins-active rounded">
                            <h1>5.</h1>
                            <span>Step Five</span>
                            </div>
                        </td>
                    </tr>
                </table>
                <hr style="background-color:gray;height:6px;">
                <!-- step 5 content start -->
                <div class="step-5-content">
                    <h3><span class="main-ins-active rounded-5 d-inline-block ps-3 pt-2" style="height:50px;width:50px;">5</span> Complete</h3>


<h3 class="text-center my-3">Installation Complete</h3>

    <div class="alert alert-success fade show alert-dismissible">
      <strong>Success!</strong> Your Application installed successfully !!!
    </div>

    <div class="card">
        <a href="<?php echo e(route('main.home')); ?>" class="stretched-link"></a>
        <div class="card-body strong bg-primary rounded-3 text-white">
            <h5 class="text-center">Click to Launch your Application</h5>
        </div>
    </div>





                </div>
                <!-- step 5 content end -->
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/erp_install/step5.blade.php ENDPATH**/ ?>