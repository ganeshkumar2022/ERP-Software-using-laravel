<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
    <h1>Hello, <?php echo e($name); ?>!</h1>
    <p><?php echo e($messageBody); ?></p>
</body>
</html>
<?php /**PATH D:\projects\ERP_Software\resources\views/admin/Client_communication.blade.php ENDPATH**/ ?>