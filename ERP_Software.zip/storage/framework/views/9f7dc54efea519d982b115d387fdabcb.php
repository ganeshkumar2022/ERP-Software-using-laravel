<?php $__env->startSection('title','ERP Software - Update Profile'); ?>

<?php $__env->startSection('main-content'); ?>

        <div id="layoutSidenav">
          <?php echo $__env->make('layout.admin_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Profile</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / View Profile</li>
                        </ol>
                        <div class="row">

                            <!-- profile content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-7">
                                <!-- alert show start -->
                                <?php if(session('success')): ?>
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> <?php echo e(session('error')); ?>

                                </div>
                                <?php endif; ?>
                                <!-- alert show end -->
                                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">Profile Page</h3></div>
                                                        <div class="card-body">
                                                            <form method="post" enctype="multipart/form-data" autocomplete="off" action="<?php echo e(route('user.update_profile')); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="name" name="name" type="text" value="<?php echo e($user->name); ?>" placeholder="Enter your first name" />
                                                                            <label for="name">Name</label>
                                                                        </div>
                                                                        <?php if($errors->has('name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="email" name="email" type="text" value="<?php echo e($user->email); ?>" placeholder="Enter your last name" />
                                                                            <label for="email">Email</label>
                                                                        </div>
                                                                        <?php if($errors->has('email')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div class=" mb-3">
                                                                    <?php if($user->profile_image==null): ?>
                      <img src="<?php echo e(asset('assets/images/avatar.avif')); ?>" height="100" width="100" class="rounded-circle">
                    <?php else: ?>
                      <img src="<?php echo e(asset('profile/'.$user->profile_image)); ?>" height="100" width="100" class="rounded-circle">
                    <?php endif; ?>
                                                                    <input class="form-control form-control-lg mt-3" id="myimage" name="myimage" type="file" />
                                                                    <?php if($errors->has('myimage')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('myimage')); ?></span>
                                    <?php endif; ?>
                                                                </div>
                                                                <div class="mt-4 mb-0">
                                                                    <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Update Profile</button></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>

                            <!-- profile content end -->

                        </div>


                    </div>
                </main>
                <?php echo $__env->make('layout.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
       <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\ERP_Software\resources\views/admin/profile.blade.php ENDPATH**/ ?>