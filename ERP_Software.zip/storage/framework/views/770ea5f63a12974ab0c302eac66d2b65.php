<?php $__env->startSection('title','ERP Software - Time Tracking'); ?>

<?php $__env->startSection('main-content'); ?>

        <div id="layoutSidenav">
          <?php echo $__env->make('layout.admin_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Time Tracking</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Time Tracking / Manage time tracking</li>
                        </ol>
                        <div class="row">

                            <!-- manage client content start -->
 <!-- alert show start -->
 <?php if(session('success')): ?>
 <div class="alert alert-success fade show alert-dismissible">
   <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
   <strong>Success!</strong> <?php echo e(session('success')); ?>

 </div>
 <?php endif; ?>
 <?php if(session('error')): ?>
 <div class="alert alert-danger fade show alert-dismissible">
   <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
   <strong>Error!</strong> <?php echo e(session('error')); ?>

 </div>
 <?php endif; ?>
 <!-- alert show end -->
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-fire-alt me-1"></i>
                                    Manage Time Tracking
                                </div>
                                <div class="card-body">
                                    <table id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Employee Name</th>
                                                <th>In time</th>
                                                <th>Out time</th>
                                                <th>Today date</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Employee Name</th>
                                                <th>In time</th>
                                                <th>Out time</th>
                                                <th>Today date</th>

                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index+1); ?></td>
                                                <td><?php echo e($employee->employee_name); ?></td>
                                                <td>
                                                      <?php echo e($employee->in_time); ?>

                                                </td>
                                                <td>
                                                       <?php echo e($employee->out_time); ?>

                                                </td>
                                                <td><?php echo e(date('d-m-Y')); ?></td>

                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- manage client content end -->

                        </div>
<?php $__errorArgs = ['in_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<script>
    alert('<?php echo e($errors->first('in_time')); ?>');
</script>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php $__errorArgs = ['out_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<script>
    alert('<?php echo e($errors->first('out_time')); ?>');
</script>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </main>
                <?php echo $__env->make('layout.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
       <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/admin/manage_time_tracking.blade.php ENDPATH**/ ?>