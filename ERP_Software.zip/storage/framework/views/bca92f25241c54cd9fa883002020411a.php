<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; ERP Software Solutions <?php echo e(date('Y')); ?></div>
            <div>
                <a href="<?php echo e(route('main.privacy_policy')); ?>">Privacy Policy</a>
                &middot;
                <a href="<?php echo e(route('main.terms_and_conditions')); ?>">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\projects\ERP_Software\resources\views/layout/admin_footer.blade.php ENDPATH**/ ?>