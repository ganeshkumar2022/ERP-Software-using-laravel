<?php $__env->startSection('title','ERP Software - Erp install step 2'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="main-erp-install-1-page">
<div class="container">
    <h1 class="text-center my-3">ERP Software Installer</h1>
    <div class="card shadow">
        <div class="card-body">
            <div class="mycontent my-3">
                <table class="table table-borderless">
                    <tr>
                        <td align="center">
                            <div class="m-one rounded py-3 position-relative bg-light border">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>1.</h1>
                            <span>Step One</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one main-ins-active py-3 rounded">
                            <h1>2.</h1>
                            <span>Step Two</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>3.</h1>
                            <span>Step Three</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>4.</h1>
                            <span>Step Four</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>5.</h1>
                            <span>Step Five</span>
                            </div>
                        </td>
                    </tr>
                </table>
                <hr style="background-color:gray;height:6px;">
                <!-- step 2 content start -->
                <div class="step-2-content">
                    <h3><span class="main-ins-active rounded-5 d-inline-block ps-3 pt-2" style="height:50px;width:50px;">2</span> Step Two</h3>
                    <h3 class="fw-bold text-center my-2">Directory Permissions and Requirements</h3>

<!-- directory requirement start -->
<table class="table table-bordered">
    <tr>
        <td width="80%">Directory & Permissions</td>
        <td>Status</td>
    </tr>
    <tr>
        <td colspan="2">
            <div class="alert alert-success alert-dismissible">
                <strong>Congratulations</strong> Your Server meets the requirements for install application.
              </div>
        </td>
    </tr>
    <tr>
        <td>../application/config/database.php is writable</td>
        <td><span class="badge bg-success rounded-5">Success</span></td>
    </tr>
    <tr>
        <td>../application/config/config.php is writable</td>
        <td><span class="badge bg-success rounded-5">Success</span></td>
    </tr>
    <tr>
        <td>php/Database.php is writable</td>
        <td><span class="badge bg-success rounded-5">Success</span></td>
    </tr>
    <tr>
        <td>sql/install.sql is writable</td>
        <td><span class="badge bg-success rounded-5">Success</span></td>
    </tr>
</table>
<!-- directory requirement end -->


<!-- server requirement start -->
<table class="table table-bordered mt-5">
    <tr>
        <td width="80%">Server Requirements</td>
        <td>Status</td>
    </tr>
    <tr>
        <td colspan="2">
            <div class="alert alert-danger alert-dismissible">
                <strong></strong> Your Server does not meet the following requirements.
              </div>
        </td>
    </tr>
    <tr>
        <td>You are Missing the <b>SMTP</b> Server</td>
        <td><span class="badge bg-warning rounded-5">Warning</span></td>
    </tr>
    <tr>
        <td>Safe Mode is <b>Off</b></td>
        <td><span class="badge bg-danger rounded-5">Error</span> <i class="fa-solid fa-circle-question"></i></td>
    </tr>
    <tr>
        <td colspan="2">
            <div class="alert alert-success alert-dismissible">
                The Following requirements were finally Met.
              </div>
        </td>
    </tr>
    <tr>
        <td>You have <b>PHP 5.3.7</b>(or greater; <b>Current Version:<?php echo e(phpversion()); ?></b>)</td>
        <td><span class="badge bg-success rounded-5">Success</span></td>
    </tr>
    <tr>
        <td>You have <b>MySQL 4.1.6</b>(or greater; <b>Current Version:<?php echo e($sql_ver); ?></b>)</td>
        <td><span class="badge bg-success rounded-5">Success</span></td>
    </tr>
    <tr>
        <td>You have the <b>Mysqli</b> Extension</td>
        <td><span class="badge bg-success rounded-5">Success</span></td>
    </tr>
    <tr>
        <td>You have the <b>Session</b> extension</td>
        <td><span class="badge bg-success rounded-5">Success</span></td>
    </tr>
</table>
<!-- server requirement end -->

<a href="<?php echo e(route('erp_install.step1')); ?>" class="btn btn-success main-ins-active border-green btn-lg rounded-1 float-start my-3 px-5">Previous</a>

<a href="<?php echo e(route('erp_install.step3')); ?>" class="btn btn-success main-ins-active border-green btn-lg rounded-1 float-end my-3 px-5">Next</a>
                </div>
                <!-- step 2 content end -->
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/erp_install/step2.blade.php ENDPATH**/ ?>