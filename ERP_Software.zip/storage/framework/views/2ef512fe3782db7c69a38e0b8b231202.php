<?php $__env->startSection('title','ERP Software - Assign Employee'); ?>

<?php $__env->startSection('main-content'); ?>

        <div id="layoutSidenav">
          <?php echo $__env->make('layout.admin_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Task</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Task / Assign Employee</li>
                        </ol>
                        <div class="row">

                            <!-- add employee content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-7">
                                <!-- alert show start -->
                                <?php if(session('success')): ?>
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> <?php echo e(session('error')); ?>

                                </div>
                                <?php endif; ?>
                                <!-- alert show end -->
                                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">Assign Employee</h3></div>
                                                        <div class="card-body">
                                                            <form method="post" autocomplete="off" action="<?php echo e(route('user.task_assign')); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <select class="form-select" id="employee_id" name="employee_id">
                                                                                <option value="">Choose Employee</option>
                                                                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($employee->id); ?>"  <?php echo e(old('employee_id')==$employee->id ? 'selected' : ''); ?>><?php echo e($employee->employee_name); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                              </select>
                                                                            <label for="employee_id">Employee Name</label>
                                                                        </div>
                                                                        <?php if($errors->has('employee_id')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('employee_id')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="task_name" name="task_name" value="<?php echo e(old('task_name')); ?>" type="text" placeholder="Enter task name" />
                                                                            <label for="task_name">Task Name</label>
                                                                        </div>
                                                                        <?php if($errors->has('task_name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('task_name')); ?></span>
                                    <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-12">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="task_description"  name="task_description" type="text" value="<?php echo e(old('task_description')); ?>" placeholder="Enter task description" />
                                                                            <label for="task_description">Task Description</label>
                                                                        </div>
                                                                        <?php if($errors->has('task_description')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('task_description')); ?></span>
                                    <?php endif; ?>
                                                                    </div>

                                                                </div>

                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="assign_date" name="assign_date" type="date" value="<?php echo e(old('assign_date')); ?>" />
                                                                            <label for="assign_date">Assign Date</label>
                                                                        </div>
                                                                        <?php if($errors->has('assign_date')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('assign_date')); ?></span>
                                    <?php endif; ?>
                                                                    </div>

                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="deadline_date" name="deadline_date" value="<?php echo e(old('deadline_date')); ?>" type="date" />
                                                                            <label for="deadline_date">Deadline Date</label>
                                                                        </div>
                                                                        <?php if($errors->has('deadline_date')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('deadline_date')); ?></span>
                                    <?php endif; ?>
                                                                    </div>

                                                                </div>


                                                                <div class=" mb-0">
                                                                    <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Add</button></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>
<script>
    function number_check(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
</script>
                            <!-- add employee content end -->

                        </div>


                    </div>
                </main>
                <?php echo $__env->make('layout.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
       <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/admin/assign_employee.blade.php ENDPATH**/ ?>