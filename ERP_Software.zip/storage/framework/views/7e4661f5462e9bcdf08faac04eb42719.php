<?php $__env->startSection('title','ERP Software - Terms & Conditions'); ?>

<?php $__env->startSection('main-content'); ?>

        <div id="layoutSidenav">
          <?php echo $__env->make('layout.admin_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Terms & Conditions</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / Terms & Conditions</li>
                        </ol>
                        <div class="row">

                            <!-- Terms & Conditions content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-12">
                                                   <!-- Terms & Conditions start -->


                                                   <h4 class="mt-3">1. Introduction</h4>
                                                   <p>Welcome to ERP Solutions. These Terms and Conditions outline the rules and regulations for the use of our ERP software.</p>

                                                   <h4>2. Acceptance of Terms</h4>
                                                   <p>By accessing and using our software, you accept and agree to be bound by these terms.</p>

                                                   <h4>3. User Accounts</h4>
                                                   <p>To use our software, you may need to create an account. You are responsible for maintaining the confidentiality of your account information.</p>

                                                   <h4>4. License</h4>
                                                   <p>We grant you a non-exclusive, non-transferable license to use the software in accordance with these Terms.</p>

                                                   <h4>5. Restrictions</h4>
                                                   <ul>
                                                       <li>You shall not reverse engineer, decompile, or disassemble the software.</li>
                                                       <li>You shall not use the software for any illegal or unauthorized purpose.</li>
                                                       <li>You shall not distribute or resell the software without permission.</li>
                                                   </ul>

                                                   <h4>6. Intellectual Property</h4>
                                                   <p>All intellectual property rights in the software are owned by ERP Solutions.</p>

                                                   <h4>7. Termination</h4>
                                                   <p>We may terminate or suspend your access to our software at any time, without prior notice, for conduct that we believe violates these Terms.</p>

                                                   <h4>8. Limitation of Liability</h4>
                                                   <p>ERP Solutions shall not be liable for any indirect, incidental, or consequential damages arising from your use of the software.</p>

                                                   <h4>9. Changes to Terms</h4>
                                                   <p>We reserve the right to modify these Terms at any time. Changes will be effective immediately upon posting on our website.</p>

                                                   <h4>10. Governing Law</h4>
                                                   <p>These Terms shall be governed by and construed in accordance with the laws of [Your Jurisdiction].</p>

                                                   <h4>11. Contact Us</h4>
                                                   <p>If you have any questions about these Terms, please contact us at +98 44544 12343.</p>

                                                   <!-- Terms & Conditions end -->
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>

                            <!-- Terms & Conditions content end -->

                        </div>


                    </div>
                </main>
                <?php echo $__env->make('layout.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
       <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/admin/terms_and_conditions.blade.php ENDPATH**/ ?>