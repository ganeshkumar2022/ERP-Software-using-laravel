<?php $__env->startSection('title','ERP Software - Assign Roles'); ?>

<?php $__env->startSection('main-content'); ?>

        <div id="layoutSidenav">
          <?php echo $__env->make('layout.admin_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Employee</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / Assign Roles</li>
                        </ol>
                        <div class="row">

                            <!-- assign roles content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-7">
                                <!-- alert show start -->
                                <?php if(session('success')): ?>
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> <?php echo e(session('error')); ?>

                                </div>
                                <?php endif; ?>
                                <!-- alert show end -->
                                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">Assign Roles</h3></div>
                                                        <div class="card-body">
                                                            <form method="post" enctype="multipart/form-data" autocomplete="off" action="<?php echo e(route('user.add_roles')); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="mb-3 mt-3">
                                                                    <label for="employee_name" class="form-label">Employee Name:</label>
                                                                    <select class="form-select" name="employee_name">
                                                                        <option value="">Choose Employee</option>
                                                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->employee_name); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                      </select>
                                                                      <?php if($errors->has('employee_name')): ?>
                                                                      <span class="text-danger"><?php echo e($errors->first('employee_name')); ?></span>
                                                                      <?php endif; ?>
                                                                  </div>
                                                                  <div class="mb-3">
                                                                    <label for="role" class="form-label">Roles:</label>
                                                                    <select class="form-select" name="role">
                                                                        <option value="">Choose Roles</option>
                                                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->role_name); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                      </select>
                                                                      <?php if($errors->has('role')): ?>
                                                                      <span class="text-danger"><?php echo e($errors->first('role')); ?></span>
                                                                      <?php endif; ?>
                                                                  </div>
                                                                  <div class="mb-3">
                                                                    <label for="salary" class="form-label">Salary:</label>
                                                                    <input type="text" class="form-control" placeholder="Enter Salary" onkeypress="return number_check(event)" name="salary">
                                                                    <?php if($errors->has('salary')): ?>
                                                                      <span class="text-danger"><?php echo e($errors->first('salary')); ?></span>
                                                                      <?php endif; ?>
                                                                  </div>
                                                                <div class="mt-4 mb-0">
                                                                    <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Allocate Role</button></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>
<script>
    function number_check(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
</script>
                            <!-- assign roles content end -->

                        </div>


                    </div>
                </main>
                <?php echo $__env->make('layout.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
       <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/admin/assign_roles.blade.php ENDPATH**/ ?>