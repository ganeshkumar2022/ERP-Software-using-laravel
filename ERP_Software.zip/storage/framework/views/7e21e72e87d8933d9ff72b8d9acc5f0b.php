<?php $__env->startSection('title','ERP Software - view Expense Report'); ?>

<?php $__env->startSection('main-content'); ?>
<script src="//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js">
</script>

        <div id="layoutSidenav">
          <?php echo $__env->make('layout.admin_side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4 hide-me">Expense</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active hide-me">Admin / View Expense Report</li>
                        </ol>
                        <div class="row">

                            <!-- view invoice content start -->

                            <div class="card mb-4">
                                <div class="card-header hide-me">
                                    <i class="fas fa-users me-1"></i>
                                    View Expense Report
                                </div>
                                <div class="card-body">
                                    <div>
                                        <center>
                                            <button id="dwnldBtn" class=" btn btn-link">Download as Excel</button>
                                        </center>
                                    </div>
                                    <a href="<?php echo e(route('user.add_expense')); ?>" class="float-end btn btn-primary mb-3 hide-me">Add Expense</a>
                                    <div id="revenue_view">
                                        <table id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Expense Amount</th>
                                                <th>Description</th>
                                                <th>Expense date</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Expense Amount</th>
                                                <th>Description</th>
                                                <th>Expense date</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index+1); ?></td>
                                                <td><?php echo e($expense->expense_amount); ?></td>
                                                <td><?php echo e($expense->description); ?></td>
                                                <td><?php echo e($expense->expense_date); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <!-- view invoice content end -->

                        </div>
                        <script>
                            $(document).ready(function () {
                                $('#dwnldBtn').on('click', function () {
                                    $("#datatablesSimple").table2excel({
                                        filename: "ExpenseReportData.xls"
                                    });
                                });
                            });
                        </script>

                    </div>
                </main>
                <div class="hide-me">
                <?php echo $__env->make('layout.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            </div>
        </div>
       <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/admin/view_expenses.blade.php ENDPATH**/ ?>