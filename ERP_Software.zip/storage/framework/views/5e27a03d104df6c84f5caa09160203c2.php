<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">

                    <center>
                    <?php if(session('user_data')->profile_image==null): ?>
                      <img src="<?php echo e(asset('assets/images/avatar.avif')); ?>" height="100" width="100" class="rounded-circle">
                    <?php else: ?>
                      <img src="<?php echo e(asset('profile/'.session('user_data')->profile_image)); ?>" height="100" width="100" class="rounded-circle">
                    <?php endif; ?>
                    <p><?php echo e(session('user_data')->name); ?> <br>
                    <span class="text-success text-capitalize"><i class="fa-solid fa-circle"></i> Admin</span></p>
                    </center>

                </div>
                <a class="nav-link" href="<?php echo e(route('user.dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>

                <!-- sale start -->
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-balance-scale"></i></div>
                    Employee
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('user.add_employee')); ?>">Add</a>
                        <a class="nav-link" href="<?php echo e(route('user.manage_employee')); ?>">Manage</a>
                        <a class="nav-link" href="<?php echo e(route('user.assign_roles')); ?>">Assign roles</a>
                        <a class="nav-link" href="<?php echo e(route('user.view_roles')); ?>">View roles</a>
                    </nav>
                </div>
                <!-- sale end -->

                <!-- customer start -->
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts2" aria-expanded="false" aria-controls="collapseLayouts2">
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    Client
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts2" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('user.add_client')); ?>">Add</a>
                        <a class="nav-link" href="<?php echo e(route('user.manage_client')); ?>">Manage</a>
                        <a class="nav-link" href="<?php echo e(route('user.communication')); ?>">Communication</a>
                    </nav>
                </div>
                <!-- customer end -->

                  <!-- supplier start -->
                  <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts3" aria-expanded="false" aria-controls="collapseLayouts3">
                    <div class="sb-nav-link-icon"><i class="fas fa-parachute-box"></i></div>
                    Project
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts3" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('user.client_project_add')); ?>">Projects</a>
                        <a class="nav-link" href="<?php echo e(route('user.manage_client_project')); ?>">Manage Projects</a>

                    </nav>
                </div>
                <!-- supplier end -->

                  <!-- product start -->
                  <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts4" aria-expanded="false" aria-controls="collapseLayouts4">
                    <div class="sb-nav-link-icon"><i class="fab fa-product-hunt"></i></div>
                    Task
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts4" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('user.assign_employee')); ?>">Assign Employee</a>
                        <a class="nav-link" href="<?php echo e(route('user.manage_tracking')); ?>">Tracking</a>
                    </nav>
                </div>
                <!-- product end -->

                <!-- time tracking start -->
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts5" aria-expanded="false" aria-controls="collapseLayouts5">
                    <div class="sb-nav-link-icon"><i class="fas fa-clock"></i></div>
                    Time Tracking
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts5" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('user.add_time_tracking')); ?>">Add Time Tracking</a>
                        <a class="nav-link" href="<?php echo e(route('user.manage_time_tracking')); ?>">Manage Time Tracking</a>
                    </nav>
                </div>
                <!-- time tracking end -->



                 <!-- stock start -->
                 <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts6" aria-expanded="false" aria-controls="collapseLayouts6">
                    <div class="sb-nav-link-icon"><i class="fas fa-shopping-basket"></i></div>
                    Invoice
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts6" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('user.invoice_create')); ?>">Create</a>
                        <a class="nav-link" href="<?php echo e(route('user.manage_invoice')); ?>">Manage</a>
                    </nav>
                </div>
                <!-- stock end -->


                 <!-- reports start -->
                 <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts8" aria-expanded="false" aria-controls="collapseLayouts8">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Reports
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts8" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('user.view_revenue_report')); ?>">Revenue Report</a>
                        <a class="nav-link" href="<?php echo e(route('user.view_expense')); ?>">Expense Report</a>
                        <a class="nav-link" href="<?php echo e(route('user.view_profit_and_loss')); ?>">Profit & Loss</a>
                    </nav>
                </div>
                <!-- reports end -->





            </div>
        </div>

    </nav>
</div>
<?php /**PATH D:\projects\ERP_Software\resources\views/layout/admin_side.blade.php ENDPATH**/ ?>