<?php $__env->startSection('title','ERP Software - Erp install step 1'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="main-erp-install-1-page">
<div class="container">
    <h1 class="text-center my-3">ERP Software Installer</h1>
    <div class="card shadow">
        <div class="card-body">
            <div class="mycontent my-3">
                <table class="table table-borderless">
                    <tr>
                        <td align="center">
                            <div class="m-one main-ins-active rounded py-3">
                            <h1>1.</h1>
                            <span>Step One</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>2.</h1>
                            <span>Step Two</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>3.</h1>
                            <span>Step Three</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>4.</h1>
                            <span>Step Four</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>5.</h1>
                            <span>Step Five</span>
                            </div>
                        </td>
                    </tr>
                </table>
                <hr style="background-color:gray;height:6px;">
                <!-- step 1 content start -->
                <div class="step-1-content">
                    <h3><span class="main-ins-active rounded-5 d-inline-block ps-3 pt-2" style="height:50px;width:50px;">1</span> Step One</h3>
                    <div class="card my-4 shadow-sm">
                        <div class="card-body">
                            <?php if(session('error')): ?>
                              <div class="alert alert-danger fade show alert-dismissible">
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                <strong>Error!</strong> <?php echo e(session('error')); ?>

                              </div>
                            <?php endif; ?>
                            <!-- form start -->
                            <form method="post" id="purchase_check" action="<?php echo e(route('erp_install.step1_check')); ?>" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <div class="row my-3">
                                  <div class="col">
                                    <h4>ERP User ID <i class="fa-solid fa-circle-question"></i></h4>
                                    <input type="text" class="form-control" placeholder="Enter user id" value="<?php echo e(old('user_id')); ?>" name="user_id">
                                    <?php if($errors->has('user_id')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('user_id')); ?></span>
                                    <?php endif; ?>
                                  </div>
                                  <div class="col">
                                    <h4>Enter Purchase Key <i class="fa-solid fa-circle-question"></i></h4>
                                    <input type="text" class="form-control" placeholder="Enter purchase key" name="purchase_key" value="<?php echo e(old('purchase_key')); ?>">
                                    <?php if($errors->has('purchase_key')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('purchase_key')); ?></span>
                                    <?php endif; ?>
                                  </div>
                                </div>
                              </form>
                            <!-- form end -->
                        </div>
                    </div>


<button type="submit" form="purchase_check" class="btn btn-success main-ins-active border-green btn-lg rounded-1 float-end my-3 px-5">Next</button>
                </div>
                <!-- step 1 content end -->
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/erp_install/main.blade.php ENDPATH**/ ?>