<?php $__env->startSection('title','ERP Software - Erp install step 4'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="main-erp-install-3-page">
<div class="container">
    <h1 class="text-center my-3">ERP Software Installer</h1>
    <div class="card shadow">
        <div class="card-body">
            <div class="mycontent my-3">
                <table class="table table-borderless">
                    <tr>
                        <td align="center">
                            <div class="m-one rounded py-3 position-relative bg-light border">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>1.</h1>
                            <span>Step One</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 position-relative rounded bg-light border">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>2.</h1>
                            <span>Step Two</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3  position-relative rounded bg-light border">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>3.</h1>
                            <span>Step Three</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 main-ins-active rounded">
                            <h1>4.</h1>
                            <span>Step Four</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>5.</h1>
                            <span>Step Five</span>
                            </div>
                        </td>
                    </tr>
                </table>
                <hr style="background-color:gray;height:6px;">
                <!-- step 4 content start -->
                <div class="step-4-content">
                    <h3><span class="main-ins-active rounded-5 d-inline-block ps-3 pt-2" style="height:50px;width:50px;">4</span> Step Four</h3>

<!-- database start -->
<p class="text-center lead">Please add your own initial username and password.Please change that after Login.</p>
<div class="card my-2 shadow-sm">
<div class="card-body">
    <?php if(session('error')): ?>
    <div class="alert alert-danger fade show alert-dismissible">
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      <strong>Error!</strong> <?php echo e(session('error')); ?>

    </div>
  <?php endif; ?>
     <!-- form content start -->
     <form action="<?php echo e(route('erp_install.step4_backend')); ?>" id="step3_form" method="post" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-2">
              <p class="mt-2 ms-4">Email</p>
            </div>
            <div class="col-md-4">
              <input type="text" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Enter Email" name="email" id="email">
              <?php if($errors->has('email')): ?>
              <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <p class="mt-2 ms-4">Password</p>
            </div>
            <div class="col-md-4">
              <input type="password" class="form-control" placeholder="Enter password" value="<?php echo e(old('password')); ?>" name="password" id="password">
              <?php if($errors->has('password')): ?>
              <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
            </div>
          </div>
      </form>
     <!-- form content end -->
</div>
</div>
<!-- database end -->



<a href="<?php echo e(route('erp_install.step3')); ?>" class="btn btn-success main-ins-active border-green btn-lg rounded-1 float-start my-3 px-5">Previous</a>

<button type="submit" form="step3_form" class="btn btn-success main-ins-active border-green btn-lg rounded-1 float-end my-3 px-5">Next</button>
                </div>
                <!-- step 4 content end -->
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/erp_install/step4.blade.php ENDPATH**/ ?>