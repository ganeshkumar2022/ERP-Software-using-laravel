<?php $__env->startSection('title','ERP Software - Forgot password page'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="main-erp-install-3-page">
<div class="container">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
    <div class="card shadow my-5">
        <div class="card-body">
            <div class="mycontent">

                                <!-- alert show start -->
                                <?php if(session('success')): ?>
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> <?php echo e(session('success')); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> <?php echo e(session('error')); ?>

                                </div>
                                <?php endif; ?>
                                <!-- alert show end -->


                <h3><i class="fa-solid fa-lock-open"></i> Forgot Password</h3>
                <hr>

                <!-- form start -->
                <form action="<?php echo e(route('main.check_forgot_password')); ?>" method="post" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3 mt-3">
                      <label for="email" class="form-label">Email:</label>
                      <input type="text" class="form-control" id="email" placeholder="Enter email" name="email">
                      <?php if($errors->has('email')): ?>
                      <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-success">Get OTP</button>

                    <p class="text-center"><a href="<?php echo e(route('main.home')); ?>" class="text-success  fw-bold">Go to Home</a></p>
                  </form>
                <!-- form end -->


            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\ERP_Software\resources\views/forgot_password.blade.php ENDPATH**/ ?>