@extends('layout.admin_layout')
@section('title','ERP Software - Manage Roles')

@section('main-content')

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Employee</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / Manage Roles</li>
                        </ol>
                        <div class="row">

                            <!-- manage employee content start -->
 <!-- alert show start -->
 @if (session('success'))
 <div class="alert alert-success fade show alert-dismissible">
   <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
   <strong>Success!</strong> {{ session('success') }}
 </div>
 @endif
 @if (session('error'))
 <div class="alert alert-danger fade show alert-dismissible">
   <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
   <strong>Error!</strong> {{ session('error') }}
 </div>
 @endif
 <!-- alert show end -->
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-users me-1"></i>
                                    Employee Roles
                                </div>
                                <div class="card-body">
                                    <table id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Employee Id</th>
                                                <th>Employee Name</th>
                                                <th>Role Name</th>
                                                <th>Salary</th>
                                                <th>Created at</th>
                                                <th>Manage</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Employee Id</th>
                                                <th>Employee Name</th>
                                                <th>Role Name</th>
                                                <th>Salary</th>
                                                <th>Created at</th>
                                                <th>Manage</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @foreach ($roles as $index=>$role)
                                            <tr>
                                                <td>{{ $index+1 }}</td>
                                                <td>{{ $role->emp_id }}</td>
                                                <td>{{ $role->employee_name }}</td>
                                                <td>{{ $role->role_name }}</td>
                                                <td>{{ $role->salary }}</td>
                                                <td>{{ $role->created_at }}</td>
                                                <td>
                                                    <div class="d-flex">
                                                    <form method="post" action="{{ route('user.delete_roles',$role->id) }}">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger ms-2"><i class="fas fa-trash"></i></button>
                                                    </form>
                                                    </div>
                                                </td>
                                            </tr>

                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- manage employee content end -->

                        </div>


                    </div>
                </main>
                @include('layout.admin_footer')
            </div>
        </div>
       @endsection
