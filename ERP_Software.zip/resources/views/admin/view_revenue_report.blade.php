@extends('layout.admin_layout')
@section('title','ERP Software - view Revenue Report')

@section('main-content')
<script src="//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js">
</script>

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4 hide-me">Revenue</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active hide-me">Admin / View Revenue Report</li>
                        </ol>
                        <div class="row">

                            <!-- view invoice content start -->

                            <div class="card mb-4">
                                <div class="card-header hide-me">
                                    <i class="fas fa-users me-1"></i>
                                    View Revenue Report
                                </div>
                                <div class="card-body">
                                    <div>
                                        <center>
                                            <button id="dwnldBtn" class=" btn btn-link">Download as Excel</button>
                                        </center>
                                    </div>
                                    <a href="{{ route('user.add_revenue') }}" class="float-end btn btn-primary mb-3 hide-me">Add Revenue</a>
                                    <div id="revenue_view">
                                        <table id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Customer name</th>
                                                <th>Remark</th>
                                                <th>Sale date</th>
                                                <th>Sale amount</th>
                                                <th>Payment method</th>
                                                <th>Discount</th>
                                                <th>Final amount</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Customer name</th>
                                                <th>Remark</th>
                                                <th>Sale date</th>
                                                <th>Sale amount</th>
                                                <th>Payment method</th>
                                                <th>Discount</th>
                                                <th>Final amount</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @foreach ($revenues as $index=>$revenue)
                                            <tr>
                                                <td>{{ $index+1 }}</td>
                                                <td>{{ $revenue->client_name }}</td>
                                                <td>{{ $revenue->remark }}</td>
                                                <td>{{ $revenue->sale_date }}</td>
                                                <td>{{ $revenue->sale_amount }}</td>
                                                <td>{{ $revenue->payment_method }}</td>
                                                <td>{{ $revenue->discount }}</td>
                                                <td>{{ $revenue->final_amount }}</td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <!-- view invoice content end -->

                        </div>
                        <script>
                            $(document).ready(function () {
                                $('#dwnldBtn').on('click', function () {
                                    $("#datatablesSimple").table2excel({
                                        filename: "RevenueReportData.xls"
                                    });
                                });
                            });
                        </script>

                    </div>
                </main>
                <div class="hide-me">
                @include('layout.admin_footer')
            </div>
            </div>
        </div>
       @endsection
