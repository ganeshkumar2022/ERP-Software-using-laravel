@extends('layout.admin_layout')
@section('title','ERP Software - Manage Tasks')

@section('main-content')

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Task</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Task / Tracking</li>
                        </ol>
                        <div class="row">

                            <!-- manage client content start -->
 <!-- alert show start -->
 @if (session('success'))
 <div class="alert alert-success fade show alert-dismissible">
   <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
   <strong>Success!</strong> {{ session('success') }}
 </div>
 @endif
 @if (session('error'))
 <div class="alert alert-danger fade show alert-dismissible">
   <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
   <strong>Error!</strong> {{ session('error') }}
 </div>
 @endif
 <!-- alert show end -->
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-fire-alt me-1"></i>
                                    Manage Tasks
                                </div>
                                <div class="card-body">
                                    <table id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Employee Name</th>
                                                <th>Task Name</th>
                                                <th>Task Description</th>
                                                <th>Assign Date</th>
                                                <th>Deadline Date</th>
                                                <th>Status</th>
                                                <th>Manage</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Employee Name</th>
                                                <th>Task Name</th>
                                                <th>Task Description</th>
                                                <th>Assign Date</th>
                                                <th>Deadline Date</th>
                                                <th>Status</th>
                                                <th>Manage</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @foreach ($tasks as $index=>$task)
                                            <tr>
                                                <td>{{ $index+1 }}</td>
                                                <td>{{ $task->employee_name }}</td>
                                                <td>{{  $task->task_name }}</td>
                                                <td>{{  $task->task_description }}</td>
                                                <td>{{  $task->assign_date }}</td>
                                                <td>{{  $task->deadline_date }}</td>
                                                <td>{{  $task->status }}</td>
                                                <td>
                                                    <div class="d-flex">
                                                        <a href="{{ route('user.edit_task',$task->id) }}" class="btn btn-success"><i class="fas fa-edit"></i></a>
                                                    <form method="post" action="{{ route('user.delete_task',$task->id) }}">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger ms-2"><i class="fas fa-trash"></i></button>
                                                    </form>
                                                    </div>
                                                </td>
                                            </tr>

                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- manage client content end -->

                        </div>


                    </div>
                </main>
                @include('layout.admin_footer')
            </div>
        </div>
       @endsection
