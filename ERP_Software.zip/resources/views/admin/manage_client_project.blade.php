@extends('layout.admin_layout')
@section('title','ERP Software - Manage Client Project')

@section('main-content')

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Client Project</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / Manage Client Project</li>
                        </ol>
                        <div class="row">

                            <!-- manage client content start -->
 <!-- alert show start -->
 @if (session('success'))
 <div class="alert alert-success fade show alert-dismissible">
   <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
   <strong>Success!</strong> {{ session('success') }}
 </div>
 @endif
 @if (session('error'))
 <div class="alert alert-danger fade show alert-dismissible">
   <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
   <strong>Error!</strong> {{ session('error') }}
 </div>
 @endif
 <!-- alert show end -->
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-fire-alt me-1"></i>
                                    Client Projects
                                </div>
                                <div class="card-body">
                                    <table id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Client Name</th>
                                                <th>Project Name</th>
                                                <th>Project Description</th>
                                                <th>Project Cost</th>
                                                <th>Used Programming Language</th>
                                                <th>Project timeline</th>
                                                <th>Created at</th>
                                                <th>Manage</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Client Name</th>
                                                <th>Project Name</th>
                                                <th>Project Description</th>
                                                <th>Project Cost</th>
                                                <th>Used Programming Language</th>
                                                <th>Project timeline</th>
                                                <th>Created at</th>
                                                <th>Manage</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @foreach ($client_projects as $index=>$client_project)
                                            <tr>
                                                <td>{{ $index+1 }}</td>
                                                <td>{{ $client_project->client_name }}</td>
                                                <td>{{ $client_project->project_name }}</td>
                                                <td>{{ $client_project->project_description }}</td>
                                                <td>{{ $client_project->project_cost }}</td>
                                                <td>{{ $client_project->programming_language }}</td>
                                                <td><span class="badge bg-success">{{ $client_project->project_timeline }}</span></td>
                                                <td>{{ $client_project->created_at }}</td>
                                                <td>
                                                    <div class="d-flex">
                                                    <a href="{{ route('user.edit_client_project',$client_project->pid) }}" class="btn btn-success"><i class="fas fa-edit"></i></a>
                                                    <form method="post" action="{{ route('user.delete_client_project',$client_project->pid) }}">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger ms-2"><i class="fas fa-trash"></i></button>
                                                    </form>
                                                    </div>
                                                </td>
                                            </tr>

                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- manage client content end -->

                        </div>


                    </div>
                </main>
                @include('layout.admin_footer')
            </div>
        </div>
       @endsection
