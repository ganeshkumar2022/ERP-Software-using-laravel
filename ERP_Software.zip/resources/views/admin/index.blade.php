@extends('layout.admin_layout')
@section('title','ERP Software - Admin Dashboard')

@section('main-content')

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / Dashboard</li>
                        </ol>
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body">{{ $clients_count }}<br>Total Clients</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="{{ route('user.manage_client') }}">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body">{{ $projects_count }}<br>Total Projects</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="{{ route('user.manage_client_project') }}">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body">{{ $employees_count }}<br>Total Employees</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="{{ route('user.manage_employee') }}">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-danger text-white mb-4">
                                    <div class="card-body">{{ $revenues }}<br>Today's Income</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="{{ route('user.view_revenue_report') }}">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-area me-1"></i>
                                        Current Year Income
                                    </div>
                                    <div class="card-body"><canvas id="myAreaChart2" style="width:100%;max-width:600px"></canvas></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-bar me-1"></i>
                                        Current Month Clients
                                    </div>
                                    <div class="card-body">
                                        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
                                        <canvas id="myChart" style="width:100%;max-width:600px"></canvas>

<script>
var xValues = ["January", "February", "March", "April", "May","June","July","August","September","October","November","December"];
var yValues = [{{ $cli_count[0]->january_clients }}, {{ $cli_count[0]->february_clients }}, {{ $cli_count[0]->march_clients }}, {{ $cli_count[0]->april_clients }}, {{ $cli_count[0]->may_clients }},{{ $cli_count[0]->june_clients }},{{ $cli_count[0]->july_clients }},{{ $cli_count[0]->august_clients }},{{ $cli_count[0]->september_clients }},{{ $cli_count[0]->october_clients }},{{ $cli_count[0]->november_clients }},{{ $cli_count[0]->december_clients }}];
var barColors = ["red", "green","blue","orange","violet","yellow","grey","brown","pink","slateblue","mediumseagreen","lightblue"];

var chart=new Chart("myChart", {
  type: "bar",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    legend: {display: false},
    title: {
      display: true,
      text: "Clients Month wise {{ date('Y') }}"
    }
  }
});

const xyValues = [
  {x:50, y:7},
  {x:60, y:8},
  {x:70, y:8},
  {x:80, y:9},
  {x:90, y:9},
  {x:100, y:9},
  {x:110, y:10},
  {x:120, y:11},
  {x:130, y:14},
  {x:140, y:14},
  {x:150, y:15}
];

var xValue = ["January", "February", "March", "April", "May","June","July","August","September","October","November","December"];
var yValue = [{{ $rev_count[0]->january_clients }}, {{ $rev_count[0]->february_clients }}, {{ $rev_count[0]->march_clients }}, {{ $rev_count[0]->april_clients }}, {{ $rev_count[0]->may_clients }},{{ $rev_count[0]->june_clients }},{{ $rev_count[0]->july_clients }},{{ $rev_count[0]->august_clients }},{{ $rev_count[0]->september_clients }},{{ $rev_count[0]->october_clients }},{{ $rev_count[0]->november_clients }},{{ $rev_count[0]->december_clients }}];

new Chart("myAreaChart2", {
  type: "line",
  data: {
    labels: xValue,
    datasets: [{
      fill: false,
      lineTension: 0,
      backgroundColor: "rgba(0,0,255,1.0)",
      borderColor: "rgba(0,0,255,0.1)",
      data: yValue
    }]
  },
  options: {
    legend: {display: false},
    /*scales: {
      yAxes: [{ticks: {min: 0, max:10}}],
    }*/
  }
});
</script>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </main>
                @include('layout.admin_footer')
            </div>
        </div>
       @endsection
