@extends('layout.admin_layout')
@section('title','ERP Software - Add Expense')

@section('main-content')

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Expense</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / View Expenses / Add Expense</li>
                        </ol>
                        <div class="row">

                            <!-- add employee content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-7">
                                <!-- alert show start -->
                                @if (session('success'))
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> {{ session('success') }}
                                </div>
                                @endif
                                @if (session('error'))
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> {{ session('error') }}
                                </div>
                                @endif
                                <!-- alert show end -->
                                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">Add Expenses</h3></div>
                                                        <div class="card-body">
                                                            <form method="post" autocomplete="off" action="{{ route('user.store_expense') }}">
                                                                @csrf
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="expense_amount" name="expense_amount" value="{{ old('expense_amount') }}" type="text" onkeypress="return number_check(event)" maxlength="10" placeholder="Enter Expense Amount" />
                                                                            <label for="expense_amount">Expense Amount</label>
                                                                        </div>
                                                                        @if ($errors->has('expense_amount'))
                                    <span class="text-danger">{{ $errors->first('expense_amount') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <select class="form-select" name="description" id="description">
                                                                                <option value="">Choose Description</option>
                                                                                <option value="Website Renewal" {{ old('description')=='Website Renewal' ? 'selected' : '' }}>Website Renewal</option>
                                                                                <option value="Domain Purchase" {{ old('description')=='Domain Purchase' ? 'selected' : '' }}>Domain Purchase</option>
                                                                                <option value="Software purchase" {{ old('description')=='Software purchase' ? 'selected' : '' }}>Software purchase</option>
                                                                                <option value="Physical Product" {{ old('description')=='Physical Product' ? 'selected' : '' }}>Physical Product</option>
                                                                                <option value="Hardware" {{ old('description')=='Hardware' ? 'selected' : '' }}>Hardware</option>
                                                                                <option value="New Laptop" {{ old('description')=='New Laptop' ? 'selected' : '' }}>New Laptop</option>
                                                                                <option value="New Computer" {{ old('description')=='New Computer' ? 'selected' : '' }}>New Computer</option>
                                                                                <option value="Service and Repairs" {{ old('description')=='Service and Repairs' ? 'selected' : '' }}>Service and Repairs</option>
                                                                                <option value="Others" {{ old('description')=='Others' ? 'selected' : '' }}>Others</option>
                                                                                <option value="Employee Salary" {{ old('description')=='Employee Salary' ? 'selected' : '' }}>Employee Salary</option>
                                                                            </select>
                                                                            <label for="description">Description</label>
                                                                        </div>
                                                                        @if ($errors->has('description'))
                                    <span class="text-danger">{{ $errors->first('description') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="expense_date" name="expense_date" type="date" value="{{ old('expense_date') }}" placeholder="Enter expense date" />
                                                                            <label for="expense_date">Expense date</label>
                                                                        </div>
                                                                        @if ($errors->has('expense_date'))
                                    <span class="text-danger">{{ $errors->first('expense_date') }}</span>
                                    @endif
                                                                    </div>

                                                                </div>

                                                                <div class="mt-4 mb-0">
                                                                    <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Add</button></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>
<script>
    function number_check(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
    function final_amount_find(discount)
    {
        var sale_amount=$("#sale_amount").val();
        if(sale_amount!="" && sale_amount>0 && discount<=30)
        {
            discount_amount=sale_amount*(discount/100);
            final_amount=sale_amount-discount_amount;
            $("#final_amount").val(final_amount);
        }
    }
</script>
                            <!-- add employee content end -->

                        </div>


                    </div>
                </main>
                @include('layout.admin_footer')
            </div>
        </div>
       @endsection
