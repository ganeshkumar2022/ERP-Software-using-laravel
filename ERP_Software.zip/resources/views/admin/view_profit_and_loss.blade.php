@extends('layout.admin_layout')
@section('title','ERP Software - view Profit and Loss Report')

@section('main-content')
<script src="//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js">
</script>

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4 hide-me">Profit and Loss</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active hide-me">Admin / View Profit and Loss Report</li>
                        </ol>
                        <div class="row">

                            <!-- view invoice content start -->

                            <div class="card mb-4">
                                <div class="card-header hide-me">
                                    <i class="fas fa-users me-1"></i>
                                    View Profit and Loss Report
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4"></div>
                                        <div class="col-md-3">
                                            <form method="GET" action="" autocomplete="off">

                                        <div class=" mb-3 mb-md-0">
                                            <input class="form-control ms-3" id="choose_date" name="choose_date" type="date" value="{{ $choose_date }}" placeholder="choose date" />
                                        </div>
                                        @if ($errors->has('choose_date'))
                                        <span class="text-danger">{{ $errors->first('choose_date') }}</span>
                                        @endif
                                    </div>
                                        <div class="col-md-4">
                                            <input type="submit" name="submit" value="Submit" class="btn btn-primary">
                                        </form>
                                        </div>


                                    </div>
                                    <div id="revenue_view">

                                        <!-- new content start -->
<br/>
<hr>
@if ($choose_date!="")

<ul class="nav nav-pills justify-content-center">
    <li class="nav-item">
      <a class="nav-link active" data-bs-toggle="pill" href="#home">Date wise</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="pill" href="#menu1">Month Wise</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="pill" href="#menu2">Year wise</a>
    </li>
  </ul>
  <!-- Tab panes -->
  <div class="tab-content">
    <div class="tab-pane container active" id="home">
        <div class="card bg-info mt-3">
            <div class="card-body">
                <h3 class="text-center fw-bold">ERP Web Solutions</h3>
                <p class="text-center">kovalam street,muthu nagar,west mambalam,chennai-621333.<br>
                phone : +91 83424 12334  ,   Fax : 777777 777777<br>
                erpwebsolutions@gmail.com
            </p>

            <table class="table table-light table-bordered">
                <thead>
                    <tr class="table-secondary">
                        <th>Income</th>
                        <th><center>Rs</center></th>
                        <th><center>Rs</center></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Project Sales</td>
                        <td align="end">
                            {{$date_wise[0]->income ?? '0.00'  }}
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <th>Total Income</th>
                        <td></td>
                        <td align="end">
                            <b>{{number_format($date_wise[0]->income??0,2)  }}</b>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="3" height="50px"></th>
                    </tr>
                    <tr  class="table-secondary">
                        <th>Expenses</th>
                        <th></th>
                        <th></th>
                    </tr>
                    @foreach ($date_wise as $row)
                    <tr>
                        <td>{{$row->description}}</td>
                        <td align="end">
                            {{$row->expense_amount}}
                        </td>
                        <td></td>
                    </tr>
                    @endforeach
                    <tr>
                        <th>Total Expenses</th>
                        <td></td>
                        <td align="end">
                            <b>{{ number_format(array_sum(array_column($date_wise,"expense_amount")),2);  }}</b>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="3" height="50px"></th>
                    </tr>
                    <tr  class="table-secondary">
                        <th>Profit/Loss</th>
                        <th></th>
                        <td align="end">
                            @php
                                $income=$date_wise[0]->income??0;
                                $expense=array_sum(array_column($date_wise,"expense_amount"));
                                $status=number_format(($income-$expense),2);
                            @endphp
                            <b>
                            @if ($status>0)
                             Profit : {{ $status }}
                             @elseif ($status<0)
                             Loss : {{ $status }}
                             @else
                             No profit/Loss
                            @endif
                            </b>
                        </td>
                    </tr>
                </tbody>
                </table>

            </div>
        </div>
    </div>
    <div class="tab-pane container fade" id="menu1">


        <!-- month wise start -->

        <div class="card bg-info mt-3">
            <div class="card-body">
                <h3 class="text-center fw-bold">ERP Web Solutions</h3>
                <p class="text-center">kovalam street,muthu nagar,west mambalam,chennai-621333.<br>
                phone : +91 83424 12334  ,   Fax : 777777 777777<br>
                erpwebsolutions@gmail.com
            </p>

            <table class="table table-light table-bordered">
                <thead>
                    <tr class="table-secondary">
                        <th>Income</th>
                        <th><center>Rs</center></th>
                        <th><center>Rs</center></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Project Sales</td>
                        <td align="end">
                            {{$month_wise[0]->income ?? '0.00'  }}
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <th>Total Income</th>
                        <td></td>
                        <td align="end">
                            <b>{{number_format($month_wise[0]->income??0,2)  }}</b>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="3" height="50px"></th>
                    </tr>
                    <tr  class="table-secondary">
                        <th>Expenses</th>
                        <th></th>
                        <th></th>
                    </tr>
                    @foreach ($month_wise as $row)
                    <tr>
                        <td>{{$row->description}}</td>
                        <td align="end">
                            {{$row->expense_amount}}
                        </td>
                        <td></td>
                    </tr>
                    @endforeach
                    <tr>
                        <th>Total Expenses</th>
                        <td></td>
                        <td align="end">
                            <b>{{ number_format(array_sum(array_column($month_wise,"expense_amount")),2);  }}</b>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="3" height="50px"></th>
                    </tr>
                    <tr  class="table-secondary">
                        <th>Profit/Loss</th>
                        <th></th>
                        <td align="end">
                            @php
                                $income=$month_wise[0]->income??0;
                                $expense=array_sum(array_column($month_wise,"expense_amount"));
                                $status=number_format(($income-$expense),2);
                            @endphp
                            <b>
                            @if ($status>0)
                             Profit : {{ $status }}
                             @elseif ($status<0)
                             Loss : {{ $status }}
                             @else
                             No profit/Loss
                            @endif
                            </b>
                        </td>
                    </tr>
                </tbody>
                </table>

            </div>
        </div>

        <!-- month wise end  -->

    </div>
    <div class="tab-pane container fade" id="menu2">


          <!-- year wise start -->

          <div class="card bg-info mt-3">
            <div class="card-body">
                <h3 class="text-center fw-bold">ERP Web Solutions</h3>
                <p class="text-center">kovalam street,muthu nagar,west mambalam,chennai-621333.<br>
                phone : +91 83424 12334  ,   Fax : 777777 777777<br>
                erpwebsolutions@gmail.com
            </p>

            <table class="table table-light table-bordered">
                <thead>
                    <tr class="table-secondary">
                        <th>Income</th>
                        <th><center>Rs</center></th>
                        <th><center>Rs</center></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Project Sales</td>
                        <td align="end">
                            {{$year_wise[0]->income ?? '0.00'  }}
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <th>Total Income</th>
                        <td></td>
                        <td align="end">
                            <b>{{number_format($year_wise[0]->income??0,2)  }}</b>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="3" height="50px"></th>
                    </tr>
                    <tr  class="table-secondary">
                        <th>Expenses</th>
                        <th></th>
                        <th></th>
                    </tr>
                    @foreach ($year_wise as $row)
                    <tr>
                        <td>{{$row->description}}</td>
                        <td align="end">
                            {{$row->expense_amount}}
                        </td>
                        <td></td>
                    </tr>
                    @endforeach
                    <tr>
                        <th>Total Expenses</th>
                        <td></td>
                        <td align="end">
                            <b>{{ number_format(array_sum(array_column($year_wise,"expense_amount")),2);  }}</b>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="3" height="50px"></th>
                    </tr>
                    <tr  class="table-secondary">
                        <th>Profit/Loss</th>
                        <th></th>
                        <td align="end">
                            @php
                                $income=$year_wise[0]->income??0;
                                $expense=array_sum(array_column($year_wise,"expense_amount"));
                                $status=number_format(($income-$expense),2);
                            @endphp
                            <b>
                            @if ($status>0)
                             Profit : {{ $status }}
                             @elseif ($status<0)
                             Loss : {{ $status }}
                             @else
                             No profit/Loss
                            @endif
                            </b>
                        </td>
                    </tr>
                </tbody>
                </table>

            </div>
        </div>

        <!-- year wise end  -->


    </div>

  </div>

  @endif

                                    </div>
                                </div>
                            </div>

                            <!-- view invoice content end -->

                        </div>
                        <script>
                            $(document).ready(function () {
                                $('#dwnldBtn').on('click', function () {
                                    $("#datatablesSimple").table2excel({
                                        filename: "RevenueReportData.xls"
                                    });
                                });
                            });
                        </script>

                    </div>
                </main>
                <div class="hide-me">
                @include('layout.admin_footer')
            </div>
            </div>
        </div>
       @endsection
