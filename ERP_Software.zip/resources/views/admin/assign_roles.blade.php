@extends('layout.admin_layout')
@section('title','ERP Software - Assign Roles')

@section('main-content')

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Employee</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / Assign Roles</li>
                        </ol>
                        <div class="row">

                            <!-- assign roles content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-7">
                                <!-- alert show start -->
                                @if (session('success'))
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> {{ session('success') }}
                                </div>
                                @endif
                                @if (session('error'))
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> {{ session('error') }}
                                </div>
                                @endif
                                <!-- alert show end -->
                                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">Assign Roles</h3></div>
                                                        <div class="card-body">
                                                            <form method="post" enctype="multipart/form-data" autocomplete="off" action="{{ route('user.add_roles') }}">
                                                                @csrf
                                                                <div class="mb-3 mt-3">
                                                                    <label for="employee_name" class="form-label">Employee Name:</label>
                                                                    <select class="form-select" name="employee_name">
                                                                        <option value="">Choose Employee</option>
                                                                        @foreach ($employees as $employee)
                                                                        <option value="{{ $employee->id }}">{{ $employee->employee_name }}</option>
                                                                        @endforeach
                                                                      </select>
                                                                      @if ($errors->has('employee_name'))
                                                                      <span class="text-danger">{{ $errors->first('employee_name') }}</span>
                                                                      @endif
                                                                  </div>
                                                                  <div class="mb-3">
                                                                    <label for="role" class="form-label">Roles:</label>
                                                                    <select class="form-select" name="role">
                                                                        <option value="">Choose Roles</option>
                                                                        @foreach ($roles as $role)
                                                                        <option value="{{ $role->id }}">{{ $role->role_name }}</option>
                                                                        @endforeach
                                                                      </select>
                                                                      @if ($errors->has('role'))
                                                                      <span class="text-danger">{{ $errors->first('role') }}</span>
                                                                      @endif
                                                                  </div>
                                                                  <div class="mb-3">
                                                                    <label for="salary" class="form-label">Salary:</label>
                                                                    <input type="text" class="form-control" placeholder="Enter Salary" onkeypress="return number_check(event)" name="salary">
                                                                    @if ($errors->has('salary'))
                                                                      <span class="text-danger">{{ $errors->first('salary') }}</span>
                                                                      @endif
                                                                  </div>
                                                                <div class="mt-4 mb-0">
                                                                    <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Allocate Role</button></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>
<script>
    function number_check(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
</script>
                            <!-- assign roles content end -->

                        </div>


                    </div>
                </main>
                @include('layout.admin_footer')
            </div>
        </div>
       @endsection
