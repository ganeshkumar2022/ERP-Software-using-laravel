@extends('layout.admin_layout')
@section('title','ERP Software - Privacy Policy')

@section('main-content')

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Privacy Policy</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / Privacy Policy</li>
                        </ol>
                        <div class="row">

                            <!-- add employee content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-12">
                                                   <!-- privacy policy start -->


<h4 class="mt-4">1. Introduction</h4>
<p>At [Your Company Name], we are committed to protecting your privacy. This Privacy Policy outlines our practices regarding the collection, use, and disclosure of your information when you use our ERP software.</p>

<h4>2. Information We Collect</h4>
<p>We may collect the following types of information:</p>
<ul>
    <li><strong>Personal Information:</strong> Name, email address, phone number, and any other information you provide.</li>
    <li><strong>Usage Data:</strong> Information on how the software is accessed and used, including IP address, browser type, pages visited, and time spent on pages.</li>
    <li><strong>Cookies:</strong> We may use cookies and similar tracking technologies to monitor activity on our software and store certain information.</li>
</ul>

<h4>3. How We Use Your Information</h4>
<p>We use the collected data for various purposes, including:</p>
<ul>
    <li>To provide and maintain our software.</li>
    <li>To notify you about changes to our software.</li>
    <li>To allow you to participate in interactive features when you choose to do so.</li>
    <li>To provide customer support.</li>
    <li>To gather analysis or valuable information so we can improve our software.</li>
    <li>To monitor the usage of our software.</li>
    <li>To detect, prevent, and address technical issues.</li>
</ul>

<h4>4. Data Sharing and Disclosure</h4>
<p>We do not sell or rent your personal information to third parties. We may share your information in the following situations:</p>
<ul>
    <li><strong>With Service Providers:</strong> We may share your information with service providers to monitor and analyze the use of our software.</li>
    <li><strong>Legal Requirements:</strong> We may disclose your information if required to do so by law or in response to valid requests by public authorities.</li>
</ul>

<h4>5. Data Security</h4>
<p>The security of your data is important to us. We strive to use commercially acceptable means to protect your personal information, but remember that no method of transmission over the Internet or method of electronic storage is 100% secure.</p>

<h4>6. Your Rights</h4>
<p>Depending on your location, you may have the following rights regarding your personal data:</p>
<ul>
    <li>The right to access your data.</li>
    <li>The right to rectification.</li>
    <li>The right to erasure.</li>
    <li>The right to restrict processing.</li>
    <li>The right to data portability.</li>
    <li>The right to object.</li>
</ul>
<p>If you wish to exercise any of these rights, please contact us.</p>

<h4>7. Changes to This Privacy Policy</h4>
<p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the effective date.</p>

<h4>8. Contact Us</h4>
<p>If you have any questions about this Privacy Policy, please contact us:</p>
<ul>
    <li><strong>Email:</strong> <a href="mailto:erpsolutions@example.com">erpsolutions@example.com</a></li>
    <li><strong>Phone:</strong> +98 45345 34234</li>
    <li><strong>Address:</strong> west mambalam,thiyagaraya nagar,chennai.</li>
</ul>
                                                   <!-- privacy policy end -->
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>
<script>
    function number_check(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
</script>
                            <!-- add employee content end -->

                        </div>


                    </div>
                </main>
                @include('layout.admin_footer')
            </div>
        </div>
       @endsection
