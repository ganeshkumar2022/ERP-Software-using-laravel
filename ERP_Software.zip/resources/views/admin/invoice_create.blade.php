@extends('layout.admin_layout')
@section('title','ERP Software - Invoice Create')

@section('main-content')

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Invoice</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Invoice / Add Invoice</li>
                        </ol>
                        <div class="row">

                            <!-- add employee content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container-fluid">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-7">
                                <!-- alert show start -->
                                @if (session('success'))
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> {{ session('success') }}
                                </div>
                                @endif
                                @if (session('error'))
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> {{ session('error') }}
                                </div>
                                @endif
                                <!-- alert show end -->
                                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">Add Invoice</h3></div>
                                                        <div class="card-body">
                                                            <form method="post" enctype="multipart/form-data" autocomplete="off" action="{{ route('user.store_invoice') }}">
                                                                @csrf
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="invoice_no" readonly value="{{ $count }}" name="invoice_no" type="text" placeholder="Enter Invoice no" />
                                                                            <label for="invoice_no">Invoice No</label>
                                                                        </div>
                                                                        @if ($errors->has('invoice_no'))
                                    <span class="text-danger">{{ $errors->first('invoice_no') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="invoice_date" name="invoice_date" readonly value="{{ date('Y-m-d') }}" type="date" placeholder="Enter Invoice Date" />
                                                                            <label for="invoice_date">Invoice Date</label>
                                                                        </div>
                                                                        @if ($errors->has('invoice_date'))
                                    <span class="text-danger">{{ $errors->first('invoice_date') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <select class="form-select" name="employee_name" id="employee_name">
                                                                                <option value="">Choose Employee</option>
                                                                                @foreach ($employees as $employee)
                                                                                <option value="{{ $employee->id }}"  {{ old('employee_name')==$employee->id ? 'selected' : '' }}>{{ $employee->employee_name }}</option>
                                                                                @endforeach
                                                                              </select>
                                                                            <label for="employee_name">Employee Name</label>
                                                                        </div>
                                                                        @if ($errors->has('employee_name'))
                                    <span class="text-danger">{{ $errors->first('employee_name') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="employee_id" name="employee_id" readonly type="text" placeholder="Enter employee id"  value="{{ old('employee_id') }}" />
                                                                            <label for="employee_id">Employee ID</label>
                                                                        </div>
                                                                        @if ($errors->has('employee_id'))
                                    <span class="text-danger">{{ $errors->first('employee_id') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>

                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="department" name="department" value="software" readonly type="text" placeholder="Enter Department" />
                                                                            <label for="department">Department</label>
                                                                        </div>
                                                                        @if ($errors->has('department'))
                                    <span class="text-danger">{{ $errors->first('department') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" readonly value="{{ old('position') }}" id="position" name="position" type="text" placeholder="Enter Position" />
                                                                            <label for="position">Position</label>
                                                                        </div>
                                                                        @if ($errors->has('position'))
                                    <span class="text-danger">{{ $errors->first('position') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>

                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="pay_period_from" value="{{ old('pay_period_from') }}" name="pay_period_from" type="date" placeholder="Enter pay period from" />
                                                                            <label for="pay_period_from">Pay period from</label>
                                                                        </div>
                                                                        @if ($errors->has('pay_period_from'))
                                    <span class="text-danger">{{ $errors->first('pay_period_from') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="pay_period_to" name="pay_period_to" value="{{ old('pay_period_to') }}" type="date" placeholder="Enter pay period to" />
                                                                            <label for="pay_period_to">Pay period to</label>
                                                                        </div>
                                                                        @if ($errors->has('pay_period_to'))
                                    <span class="text-danger">{{ $errors->first('pay_period_to') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>

                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <select class="form-select" name="total_working_days">
                                                                                <option value="29">29</option>
                                                                                <option value="30" selected>30</option>
                                                                                <option value="31">31</option>
                                                                              </select>
                                                                            <label for="total_working_days">Total Working Days</label>
                                                                        </div>
                                                                        @if ($errors->has('total_working_days'))
                                    <span class="text-danger">{{ $errors->first('total_working_days') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="present_days" name="present_days" onkeypress="return number_check(event)" value="{{ old('present_days') }}" type="text" placeholder="Enter present days" />
                                                                            <label for="present_days">Present Days</label>
                                                                        </div>
                                                                        @if ($errors->has('present_days'))
                                    <span class="text-danger">{{ $errors->first('present_days') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>

                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="gross_pay" onkeypress="return number_check(event)" value="{{ old('gross_pay') }}" readonly name="gross_pay" type="text" placeholder="Enter gross pay" />
                                                                            <label for="gross_pay">Gross pay</label>
                                                                        </div>
                                                                        @if ($errors->has('gross_pay'))
                                    <span class="text-danger">{{ $errors->first('gross_pay') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="tax" name="tax" value="{{ old('tax') }}" onkeypress="return number_check(event)" type="text" placeholder="Enter tax no" />
                                                                            <label for="tax">Tax</label>
                                                                        </div>
                                                                        @if ($errors->has('tax'))
                                    <span class="text-danger">{{ $errors->first('tax') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>

                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="health_insurance" value="{{ old('health_insurance') }}" name="health_insurance" type="text" onkeypress="return number_check(event)" placeholder="Enter health insurance" />
                                                                            <label for="health_insurance">Health Insurance</label>
                                                                        </div>
                                                                        @if ($errors->has('health_insurance'))
                                    <span class="text-danger">{{ $errors->first('health_insurance') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="retirement" name="retirement" value="{{ old('retirement') }}" type="text" onkeypress="return number_check(event)" placeholder="Enter your Retirement" />
                                                                            <label for="retirement">Retirement</label>
                                                                        </div>
                                                                        @if ($errors->has('retirement'))
                                    <span class="text-danger">{{ $errors->first('retirement') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>

                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="total_deduction" value="{{ old('total_deduction') }}" name="total_deduction" onkeypress="return number_check(event)" type="text" placeholder="Enter total deduction" />
                                                                            <label for="total_deduction">total Deductions</label>
                                                                        </div>
                                                                        @if ($errors->has('total_deduction'))
                                    <span class="text-danger">{{ $errors->first('total_deduction') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="net_pay" onkeypress="return number_check(event)" name="net_pay" value="{{ old('net_pay') }}" type="text" placeholder="Enter net pay" />
                                                                            <label for="net_pay">Net pay</label>
                                                                        </div>
                                                                        @if ($errors->has('net_pay'))
                                    <span class="text-danger">{{ $errors->first('net_pay') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>

                                                                <div class="mt-4 mb-0">
                                                                    <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Add</button></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>
<script>
    function number_check(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
    $(document).ready(function(){
        $("#employee_name").change(function(){
            var eid=$(this).val();
            if(eid!="")
            {
                $.post("{{ route('user.get_employee_data') }}",{eid:eid,_token:"{{csrf_token()}}"},function(response){
                    $("#employee_id").val(response.employee_id);
                    $("#gross_pay").val(response.salary);
                    $("#position").val(response.role_name);
                });
            }
            else
            {

            }
        });
    });
</script>
                            <!-- add employee content end -->

                        </div>


                    </div>
                </main>
                @include('layout.admin_footer')
            </div>
        </div>
       @endsection
