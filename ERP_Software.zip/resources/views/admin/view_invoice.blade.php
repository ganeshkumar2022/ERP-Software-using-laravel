@extends('layout.admin_layout')
@section('title','ERP Software - view Invoice')

@section('main-content')


        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4 hide-me">Invoice</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active hide-me">Invoice / Manage / View</li>
                        </ol>
                        <div class="row">

                            <!-- view invoice content start -->

                            <div class="card mb-4">
                                <div class="card-header hide-me">
                                    <i class="fas fa-users me-1"></i>
                                    View Invoice
                                </div>
                                <div class="card-body">
                                    <button id="download" onclick="download_pdf()" class="float-end btn btn-primary mb-3 hide-me">Download PDF</button>
                                    <div id="invoice_view">
                                        <table class="table table-bordered">
                                            <tr>
                                                <th>Invoice Number</th>
                                                <th>Invoice Date</th>
                                            </tr>
                                            <tr>
                                                <td>{{ $invoice->invoice_no }}</td>
                                                <td>{{ $invoice->invoice_date }}</td>
                                            </tr>
                                        </table>

                                        <table class="table table-bordered mt-3">
                                            <tr>
                                                <th width="40%">Employee Information</th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>Name</th>
                                                <td>{{ $invoice->emp_name }}</td>
                                            </tr>
                                            <tr>
                                                <th>Employee ID</th>
                                                <td>{{ $invoice->employee_id }}</td>
                                            </tr>
                                            <tr>
                                                <th>Department</th>
                                                <td>{{ $invoice->department }}</td>
                                            </tr>
                                            <tr>
                                                <th>Position</th>
                                                <td>{{ $invoice->position }}</td>
                                            </tr>
                                        </table>

                                        <table class="table table-bordered mt-3">
                                            <tr>
                                                <th width="40%">Pay period</th>
                                                <th>{{ $invoice->pay_period_from }} to {{ $invoice->pay_period_to }}</th>
                                            </tr>
                                            <tr>
                                                <th>Total working days</th>
                                                <td>{{ $invoice->total_working_days }}</td>
                                            </tr>
                                            <tr>
                                                <th>Present Days</th>
                                                <td>{{ $invoice->present_days }}</td>
                                            </tr>
                                            <tr>
                                                <th>Gross pay</th>
                                                <td>&#8377;{{ $invoice->gross_pay }}</td>
                                            </tr>
                                        </table>

                                        <table class="table table-bordered mt-3">
                                            <tr>
                                                <th width="40%">Deductions</th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>Tax</th>
                                                <td>&#8377;{{ $invoice->tax }}</td>
                                            </tr>
                                            <tr>
                                                <th>Health Insurance</th>
                                                <td>&#8377;{{ $invoice->health_insurance }}</td>
                                            </tr>
                                            <tr>
                                                <th>Retirement</th>
                                                <td>&#8377;{{ $invoice->retirement }}</td>
                                            </tr>
                                            <tr>
                                                <th>Total Deductions</th>
                                                <td>&#8377;{{ $invoice->total_deduction }}</td>
                                            </tr>
                                        </table>

                                        <table class="table table-bordered mt-3">
                                            <tr>
                                                <th width="40%"></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>Net Pay</th>
                                                <td>&#8377;{{ $invoice->net_pay }}</td>
                                            </tr>
                                        </table>

                                        <table class="table table-bordered mt-3">
                                            <tr>
                                                <th width="80%">Payment Instruction</th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <td>please transfer the net pay amount</td>
                                                <td></td>
                                            </tr>
                                        </table>

                                        <table class="table table-bordered mt-3">
                                            <tr>
                                                <th width="80%">Notes/Comments:</th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <td>Thanks for your hardwork.</td>
                                                <td></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <!-- view invoice content end -->

                        </div>

<script>
    function download_pdf()
    {
        $(".hide-me").hide();
        window.print();
        $(".hide-me").show();
    }
</script>
                    </div>
                </main>
                <div class="hide-me">
                @include('layout.admin_footer')
            </div>
            </div>
        </div>
       @endsection
