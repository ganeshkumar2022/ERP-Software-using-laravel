@extends('layout.admin_layout')
@section('title','ERP Software - Manage Employee')

@section('main-content')

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Employee</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / Manage Employee</li>
                        </ol>
                        <div class="row">

                            <!-- manage employee content start -->
 <!-- alert show start -->
 @if (session('success'))
 <div class="alert alert-success fade show alert-dismissible">
   <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
   <strong>Success!</strong> {{ session('success') }}
 </div>
 @endif
 @if (session('error'))
 <div class="alert alert-danger fade show alert-dismissible">
   <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
   <strong>Error!</strong> {{ session('error') }}
 </div>
 @endif
 <!-- alert show end -->
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-users me-1"></i>
                                    Employee Data
                                </div>
                                <div class="card-body">
                                    <table id="datatablesSimple">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Employee ID</th>
                                                <th>Employee Name</th>
                                                <th>Age</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Educational Qualification</th>
                                                <th>Profile Image</th>
                                                <th>Manage</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Employee ID</th>
                                                <th>Employee Name</th>
                                                <th>Age</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Educational Qualification</th>
                                                <th>Profile Image</th>
                                                <th>Manage</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            @foreach ($employees as $index=>$employee)
                                            <tr>
                                                <td>{{ $index+1 }}</td>
                                                <td>{{ $employee->employee_id }}</td>
                                                <td>{{ $employee->employee_name }}</td>
                                                <td>{{ $employee->age }}</td>
                                                <td>{{ $employee->email }}</td>
                                                <td>{{ $employee->mobile }}</td>
                                                <td>{{ $employee->educational_qualification }}</td>
                                                <td><img src=" {{ asset('employee_profile/'.$employee->profile_image) }}" height="100" width="100"></td>
                                                <td>
                                                    <div class="d-flex">
                                                    <a href="{{ route('user.edit_employee',$employee->id) }}" class="btn btn-success"><i class="fas fa-edit"></i></a>
                                                    <form method="post" action="{{ route('user.delete_employee',$employee->id) }}">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger ms-2"><i class="fas fa-trash"></i></button>
                                                    </form>
                                                    </div>
                                                </td>
                                            </tr>

                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- manage employee content end -->

                        </div>


                    </div>
                </main>
                @include('layout.admin_footer')
            </div>
        </div>
       @endsection
