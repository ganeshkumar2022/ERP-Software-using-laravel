@extends('layout.admin_layout')
@section('title','ERP Software - Add Revenue')

@section('main-content')

        <div id="layoutSidenav">
          @include('layout.admin_side')
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Revenue</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Admin / View Revenue / Add Revenue</li>
                        </ol>
                        <div class="row">

                            <!-- add employee content start -->

                            <div id="layoutAuthentication">
                                <div id="layoutAuthentication_content">
                                    <main>
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-lg-7">
                                <!-- alert show start -->
                                @if (session('success'))
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> {{ session('success') }}
                                </div>
                                @endif
                                @if (session('error'))
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> {{ session('error') }}
                                </div>
                                @endif
                                <!-- alert show end -->
                                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">Add Revenue</h3></div>
                                                        <div class="card-body">
                                                            <form method="post" autocomplete="off" action="{{ route('user.store_revenue') }}">
                                                                @csrf
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <select class="form-select" name="client_name" id="client_name">
                                                                                <option value="">Choose Client Name</option>
                                                                                @foreach ($clients as $client)
                                                                                <option value="{{ $client->id }}"  {{ old('client_name')==$client->id ? 'selected' : '' }}>{{ $client->client_name }}</option>
                                                                                @endforeach
                                                                            </select>
                                                                            <label for="client_name">Client Name</label>
                                                                        </div>
                                                                        @if ($errors->has('client_name'))
                                    <span class="text-danger">{{ $errors->first('client_name') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <input class="form-control" id="remark" name="remark" value="{{ old('remark') }}" type="text" placeholder="Enter your remark" />
                                                                            <label for="remark">Remark</label>
                                                                        </div>
                                                                        @if ($errors->has('remark'))
                                    <span class="text-danger">{{ $errors->first('remark') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="sale_date" name="sale_date" type="date" value="{{ old('sale_date') }}" placeholder="Entersale date" />
                                                                            <label for="sale_date">Sale date</label>
                                                                        </div>
                                                                        @if ($errors->has('sale_date'))
                                    <span class="text-danger">{{ $errors->first('sale_date') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input class="form-control" id="sale_amount" name="sale_amount" value="{{ old('sale_amount') }}" type="text" onkeypress="return number_check(event)" maxlength="10" placeholder="Enter Sale Amount" />
                                                                            <label for="sale_amount">Sale Amount</label>
                                                                        </div>
                                                                        @if ($errors->has('sale_amount'))
                                    <span class="text-danger">{{ $errors->first('sale_amount') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>

                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input onkeyup="final_amount_find(this.value)" class="form-control" id="discount" name="discount" value="{{ old('discount') }}" type="text" onkeypress="return number_check(event)" maxlength="10" placeholder="Enter Discount" />
                                                                            <label for="discount">Discount (%)</label>
                                                                        </div>
                                                                        @if ($errors->has('discount'))
                                    <span class="text-danger">{{ $errors->first('discount') }}</span>
                                    @endif
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating">
                                                                            <select class="form-select" name="payment_method" id="payment_method">
                                                                                <option value="">Choose Payment method</option>
                                                                                <option value="Net Banking" {{ old('payment_method')=='Net Banking' ? 'selected' : '' }}>Net Banking</option>
                                                                                <option value="UPI" {{ old('payment_method')=='UPI' ? 'selected' : '' }}>UPI</option>
                                                                                <option value="Cash" {{ old('payment_method')=='Cash' ? 'selected' : '' }}>Cash</option>
                                                                            </select>
                                                                            <label for="payment_method">Payment Method</label>
                                                                        </div>
                                                                        @if ($errors->has('payment_method'))
                                    <span class="text-danger">{{ $errors->first('payment_method') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>
                                                                <div class="row mb-3">
                                                                    <div class="col-md-6">
                                                                        <div class="form-floating mb-3 mb-md-0">
                                                                            <input readonly class="form-control" id="final_amount" name="final_amount" value="{{ old('final_amount') }}" type="text" onkeypress="return number_check(event)" maxlength="10" placeholder="Enter Final Amount" />
                                                                            <label for="final_amount">Final Amount</label>
                                                                        </div>
                                                                        @if ($errors->has('final_amount'))
                                    <span class="text-danger">{{ $errors->first('final_amount') }}</span>
                                    @endif
                                                                    </div>
                                                                </div>


                                                                <div class="mt-4 mb-0">
                                                                    <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Add</button></div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </main>
                                </div>
<script>
    function number_check(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
    function final_amount_find(discount)
    {
        var sale_amount=$("#sale_amount").val();
        if(sale_amount!="" && sale_amount>0 && discount<=30)
        {
            discount_amount=sale_amount*(discount/100);
            final_amount=sale_amount-discount_amount;
            $("#final_amount").val(final_amount);
        }
    }
</script>
                            <!-- add employee content end -->

                        </div>


                    </div>
                </main>
                @include('layout.admin_footer')
            </div>
        </div>
       @endsection
