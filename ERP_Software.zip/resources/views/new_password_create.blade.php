@extends('layout.master')
@section('title','ERP Software - Forgot password page')
@section('main-content')
<div class="main-erp-install-3-page">
<div class="container">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
    <div class="card shadow my-5">
        <div class="card-body">
            <div class="mycontent">

                                <!-- alert show start -->
                                @if (session('success'))
                                <div class="alert alert-success fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Success!</strong> {{ session('success') }}
                                </div>
                                @endif
                                @if (session('error'))
                                <div class="alert alert-danger fade show alert-dismissible">
                                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                  <strong>Error!</strong> {{ session('error') }}
                                </div>
                                @endif
                                <!-- alert show end -->


                <h3>Enter your OTP :</h3>
                <hr>

                <!-- form start -->
                <form action="{{ route('main.otp_verify') }}" method="post" autocomplete="off">
                    @csrf
                    <div class="mb-3 mt-3">
                      <label for="otp" class="form-label">OTP:</label>
                      <input type="text" class="form-control" onkeypress="return number_exists(event)" id="otp" maxlength="4" placeholder="Enter OTP" name="otp">
                      @if ($errors->has('otp'))
                      <span class="text-danger">{{ $errors->first('otp') }}</span>
                    @endif
                    </div>
                    <button type="submit" class="btn btn-success">Verify</button>

                    <p class="text-center"><a href="{{ route('main.home') }}" class="text-success  fw-bold">Go to Home</a></p>
                  </form>
                <!-- form end -->
<script>
    function number_exists(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
</script>

            </div>
        </div>
    </div>
</div>
</div>
</div>
@if (session('flash_alert'))
    <script>
        alert('{{ session("flash_alert") }}');
    </script>
@endif
</div>
@endsection
