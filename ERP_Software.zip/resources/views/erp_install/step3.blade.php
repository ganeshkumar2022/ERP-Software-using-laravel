@extends('layout.master')
@section('title','ERP Software - Erp install step 3')
@section('main-content')
<div class="main-erp-install-3-page">
<div class="container">
    <h1 class="text-center my-3">ERP Software Installer</h1>
    <div class="card shadow">
        <div class="card-body">
            <div class="mycontent my-3">
                <table class="table table-borderless">
                    <tr>
                        <td align="center">
                            <div class="m-one rounded py-3 position-relative bg-light border">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>1.</h1>
                            <span>Step One</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 position-relative rounded bg-light border">
                                <i class="fa-solid fa-square-check fa-xl position-absolute" style="font-size:30px;color: #52e84f;center:0;top:0;"></i>
                            <h1>2.</h1>
                            <span>Step Two</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 main-ins-active rounded">
                            <h1>3.</h1>
                            <span>Step Three</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>4.</h1>
                            <span>Step Four</span>
                            </div>
                        </td>
                        <td align="center">
                            <div class="m-one py-3 rounded">
                            <h1>5.</h1>
                            <span>Step Five</span>
                            </div>
                        </td>
                    </tr>
                </table>
                <hr style="background-color:gray;height:6px;">
                <!-- step 3 content start -->
                <div class="step-3-content">
                    <h3><span class="main-ins-active rounded-5 d-inline-block ps-3 pt-2" style="height:50px;width:50px;">3</span> Step Three</h3>

<!-- database start -->
<div class="card my-2 shadow-sm">
<div class="card-body">
     <!-- form content start -->
     <form action="{{ route('erp_install.step3_backend') }}" id="step3_form" method="post" autocomplete="off">
        @csrf
        <div class="mb-3 mt-3">
          <label for="dbname" class="form-label fw-bold">Database Name:</label>
          <input type="text" class="form-control" id="dbname" placeholder="Enter Database name" name="dbname">
        </div>
        @if ($errors->has('dbname'))
        <span class="text-danger">{{ $errors->first('dbname') }}</span>
      @endif
        <div class="">
          <label for="username" class="form-label fw-bold">Username:</label>
          <input type="text" class="form-control" id="username" placeholder="Enter Username" name="username">
        </div>
        @if ($errors->has('username'))
        <span class="text-danger">{{ $errors->first('username') }}</span>
      @endif
        <div class="">
            <label for="password" class="form-label fw-bold">Password:</label>
            <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
          </div>
          @if ($errors->has('password'))
          <span class="text-danger">{{ $errors->first('password') }}</span>
        @endif
          <div class="">
            <label for="hostname" class="form-label fw-bold">Host Name: <i class="fa-solid fa-circle-question"></i></label>
            <input type="text" class="form-control" id="hostname" placeholder="Enter Host name" name="hostname">
          </div>
          @if ($errors->has('hostname'))
          <span class="text-danger">{{ $errors->first('hostname') }}</span>
        @endif
      </form>
     <!-- form content end -->
</div>
</div>
<!-- database end -->



<a href="{{ route('erp_install.step2') }}" class="btn btn-success main-ins-active border-green btn-lg rounded-1 float-start my-3 px-5">Previous</a>

<button type="submit" form="step3_form" class="btn btn-success main-ins-active border-green btn-lg rounded-1 float-end my-3 px-5">Next</button>
                </div>
                <!-- step 3 content end -->
            </div>
        </div>
    </div>
</div>
</div>
@endsection
